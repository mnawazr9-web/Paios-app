package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.paios.data.local.PaiosDatabase
import com.example.paios.data.local.PaiosRepository
import com.example.paios.model.AiOperationMode
import com.example.paios.ui.components.PaiosNavBar
import com.example.paios.ui.components.PaiosTopBar
import com.example.paios.ui.components.SecurityConfirmationDialog
import com.example.paios.ui.screens.*
import com.example.paios.ui.viewmodel.PaiosNavTab
import com.example.paios.ui.viewmodel.PaiosViewModel
import com.example.paios.ui.viewmodel.PaiosViewModelFactory
import com.example.ui.theme.CyberBackground
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private val viewModel: PaiosViewModel by viewModels {
        val db = PaiosDatabase.getInstance(applicationContext)
        val repo = PaiosRepository(
            db.projectDao(),
            db.projectFileDao(),
            db.memoryDao(),
            db.auditLogDao()
        )
        PaiosViewModelFactory(application, repo)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                PaiosApp(viewModel)
            }
        }
    }
}

@Composable
fun PaiosApp(viewModel: PaiosViewModel) {
    val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
    val metrics by viewModel.metrics.collectAsStateWithLifecycle()
    val messages by viewModel.messages.collectAsStateWithLifecycle()
    val activeAgent by viewModel.activeAgent.collectAsStateWithLifecycle()
    val activeStep by viewModel.activeWorkflowStep.collectAsStateWithLifecycle()
    val isGenerating by viewModel.isGenerating.collectAsStateWithLifecycle()

    val projects by viewModel.allProjects.collectAsStateWithLifecycle()
    val activeProject by viewModel.activeProject.collectAsStateWithLifecycle()
    val activeFiles by viewModel.activeProjectFiles.collectAsStateWithLifecycle()
    val selectedFile by viewModel.selectedFile.collectAsStateWithLifecycle()
    val testReport by viewModel.testReport.collectAsStateWithLifecycle()

    val agentsState by viewModel.agentsState.collectAsStateWithLifecycle()
    val terminalLogs by viewModel.terminalLogs.collectAsStateWithLifecycle()
    val memories by viewModel.allMemories.collectAsStateWithLifecycle()
    val auditLogs by viewModel.recentAuditLogs.collectAsStateWithLifecycle()
    val securityRequest by viewModel.securityRequest.collectAsStateWithLifecycle()

    val ollamaConfig by viewModel.ollamaConfig.collectAsStateWithLifecycle()
    val localModels by viewModel.localModels.collectAsStateWithLifecycle()
    val latestBenchmark by viewModel.latestBenchmark.collectAsStateWithLifecycle()
    val isTestingConnection by viewModel.isTestingConnection.collectAsStateWithLifecycle()
    val downloadingModelId by viewModel.downloadingModelId.collectAsStateWithLifecycle()

    val isListening by viewModel.voiceManager.isListening.collectAsStateWithLifecycle()
    val isSpeaking by viewModel.voiceManager.isSpeaking.collectAsStateWithLifecycle()

    Scaffold(
        topBar = {
            PaiosTopBar(
                metrics = metrics,
                activeAgent = activeAgent,
                isGenerating = isGenerating,
                onEmergencyStop = { viewModel.triggerEmergencyStop() },
                onResumeSystem = { viewModel.resetEmergencyStop() },
                onModeClick = {
                    val nextMode = when (metrics.activeMode) {
                        AiOperationMode.OFFLINE_ALLAMA -> AiOperationMode.ONLINE
                        AiOperationMode.ONLINE -> AiOperationMode.HYBRID
                        AiOperationMode.HYBRID -> AiOperationMode.OFFLINE_ALLAMA
                    }
                    viewModel.setAiMode(nextMode)
                }
            )
        },
        bottomBar = {
            PaiosNavBar(
                currentTab = currentTab,
                onTabSelected = { viewModel.selectTab(it) }
            )
        },
        containerColor = CyberBackground,
        modifier = Modifier.fillMaxSize()
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(CyberBackground)
        ) {
            when (currentTab) {
                PaiosNavTab.CHAT_VOICE -> {
                    ChatScreen(
                        messages = messages,
                        activeStep = activeStep,
                        isGenerating = isGenerating,
                        isListening = isListening,
                        isSpeaking = isSpeaking,
                        onSendMessage = { viewModel.sendUserPrompt(it) },
                        onToggleListen = {
                            val newListening = !isListening
                            viewModel.voiceManager.setListening(newListening)
                            if (newListening) {
                                viewModel.sendUserPrompt("ایک نیا پروجیکٹ بناؤ")
                            }
                        },
                        onStopSpeak = { viewModel.voiceManager.stopSpeaking() },
                        onNavigateToIde = { viewModel.selectTab(PaiosNavTab.PROJECT_IDE) }
                    )
                }

                PaiosNavTab.PROJECT_IDE -> {
                    ProjectIDEScreen(
                        projects = projects,
                        activeProject = activeProject,
                        files = activeFiles,
                        selectedFile = selectedFile,
                        testReport = testReport,
                        onSelectProject = { viewModel.selectProject(it) },
                        onSelectFile = { viewModel.selectFile(it) },
                        onSaveFileContent = { fileId, content -> viewModel.saveFileContent(fileId, content) },
                        onDeleteFile = { viewModel.requestDeleteFile(it) },
                        onCreateNewFile = { projId, name, content, lang -> viewModel.createNewFile(projId, name, content, lang) },
                        onRunCode = { code, lang -> viewModel.runTerminalCommand("gradle test") },
                        onTriggerAutonomousBuild = { prompt -> viewModel.sendUserPrompt("Build $prompt") },
                        onRunTests = { viewModel.runProjectTests() }
                    )
                }

                PaiosNavTab.AGENT_MATRIX -> {
                    AgentMatrixScreen(
                        agentsState = agentsState,
                        onDispatchTaskToAgent = { agent, prompt ->
                            viewModel.sendUserPrompt("[$agent] $prompt")
                            viewModel.selectTab(PaiosNavTab.CHAT_VOICE)
                        }
                    )
                }

                PaiosNavTab.OS_TOOLS -> {
                    OSToolsScreen(
                        apps = viewModel.osToolsManager.systemApps,
                        terminalLogs = terminalLogs,
                        onLaunchApp = { appId, query -> viewModel.launchApp(appId, query) },
                        onRunTerminalCommand = { viewModel.runTerminalCommand(it) }
                    )
                }

                PaiosNavTab.MEMORY_BRAIN -> {
                    MemoryBrainScreen(
                        metrics = metrics,
                        memories = memories,
                        auditLogs = auditLogs,
                        ollamaConfig = ollamaConfig,
                        localModels = localModels,
                        latestBenchmark = latestBenchmark,
                        isTestingConnection = isTestingConnection,
                        downloadingModelId = downloadingModelId,
                        onAddMemory = { type, title, content, tags -> viewModel.addMemory(type, title, content, tags) },
                        onDeleteMemory = { viewModel.deleteMemory(it) },
                        onSetAiMode = { viewModel.setAiMode(it) },
                        onSetModel = { viewModel.setSelectedModel(it) },
                        onUpdateOllamaConfig = { viewModel.updateOllamaConfig(it) },
                        onTestOllamaConnection = { viewModel.testOllamaServerConnection() },
                        onActivateLocalModel = { viewModel.activateLocalModel(it) },
                        onDownloadLocalModel = { viewModel.downloadLocalModel(it) },
                        onRunLocalBenchmark = { viewModel.runLocalModelBenchmark(it) }
                    )
                }
            }

            // Security Confirmation Dialog Overlay
            securityRequest?.let { req ->
                SecurityConfirmationDialog(request = req)
            }
        }
    }
}
