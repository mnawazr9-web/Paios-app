package com.example.paios.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

@Composable
fun VoiceWaveformBar(
    isListening: Boolean,
    isSpeaking: Boolean,
    onToggleListen: () -> Unit,
    onStopSpeak: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "wave")
    val wave1 by infiniteTransition.animateFloat(
        initialValue = 0.2f, targetValue = 1.0f,
        animationSpec = infiniteRepeatable(tween(400, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "w1"
    )
    val wave2 by infiniteTransition.animateFloat(
        initialValue = 0.8f, targetValue = 0.3f,
        animationSpec = infiniteRepeatable(tween(550, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "w2"
    )
    val wave3 by infiniteTransition.animateFloat(
        initialValue = 0.4f, targetValue = 0.9f,
        animationSpec = infiniteRepeatable(tween(350, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "w3"
    )

    Surface(
        color = CyberSurfaceElevated,
        shape = RoundedCornerShape(16.dp),
        border = BorderStroke(1.dp, if (isListening || isSpeaking) CyberCyan else CyberBorder),
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 4.dp)
    ) {
        Row(
            modifier = Modifier
                .padding(horizontal = 12.dp, vertical = 8.dp)
                .fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(
                    onClick = onToggleListen,
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(
                            if (isListening) Brush.linearGradient(listOf(CyberCrimson, CyberPink))
                            else Brush.linearGradient(listOf(CyberCyan, CyberBlue))
                        )
                        .testTag("voice_mic_button")
                ) {
                    Icon(
                        imageVector = if (isListening) Icons.Default.MicOff else Icons.Default.Mic,
                        contentDescription = "Voice Input",
                        tint = CyberBackground,
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(Modifier.width(10.dp))

                Column {
                    Text(
                        text = when {
                            isListening -> "Listening... (اردو یا English میں بولیں)"
                            isSpeaking -> "PAIOS Voice Agent Speaking..."
                            else -> "Voice Agent Ready (Tap mic to speak)"
                        },
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = if (isListening) CyberPink else if (isSpeaking) CyberGreen else CyberTextPrimary,
                        fontSize = 12.sp
                    )
                    Text(
                        text = "Natural Speech-to-Intent Pipeline Active",
                        style = MaterialTheme.typography.bodySmall,
                        color = CyberTextTertiary,
                        fontSize = 10.sp
                    )
                }
            }

            // Real-time Audio Waveform
            Row(
                horizontalArrangement = Arrangement.spacedBy(3.dp),
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.height(28.dp)
            ) {
                val heights = if (isListening || isSpeaking) {
                    listOf(wave1, wave2, wave3, wave1 * 0.7f, wave2 * 1.1f, wave3 * 0.8f)
                } else {
                    listOf(0.2f, 0.3f, 0.2f, 0.4f, 0.2f, 0.3f)
                }

                heights.forEach { h ->
                    val barHeight = (h * 24).coerceIn(4f, 26f).dp
                    Box(
                        modifier = Modifier
                            .width(3.dp)
                            .height(barHeight)
                            .clip(RoundedCornerShape(2.dp))
                            .background(
                                if (isListening) CyberPink
                                else if (isSpeaking) CyberGreen
                                else CyberTextTertiary.copy(alpha = 0.5f)
                            )
                    )
                }

                if (isSpeaking) {
                    Spacer(Modifier.width(6.dp))
                    IconButton(
                        onClick = onStopSpeak,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            Icons.Default.VolumeUp,
                            contentDescription = "Stop Speech",
                            tint = CyberGreen,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}
