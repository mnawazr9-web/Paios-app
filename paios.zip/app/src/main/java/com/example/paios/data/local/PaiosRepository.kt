package com.example.paios.data.local

import kotlinx.coroutines.flow.Flow
import java.util.UUID

class PaiosRepository(
    private val projectDao: ProjectDao,
    private val projectFileDao: ProjectFileDao,
    private val memoryDao: MemoryDao,
    private val auditLogDao: AuditLogDao
) {
    val allProjects: Flow<List<ProjectEntity>> = projectDao.getAllProjects()
    val allMemories: Flow<List<MemoryEntity>> = memoryDao.getAllMemories()
    val recentAuditLogs: Flow<List<AuditLogEntity>> = auditLogDao.getRecentAuditLogs()

    fun getFilesForProject(projectId: String): Flow<List<ProjectFileEntity>> =
        projectFileDao.getFilesForProject(projectId)

    suspend fun insertProject(project: ProjectEntity) = projectDao.insertProject(project)
    suspend fun updateProject(project: ProjectEntity) = projectDao.updateProject(project)
    suspend fun deleteProject(projectId: String) {
        projectFileDao.deleteFilesForProject(projectId)
        projectDao.deleteProjectById(projectId)
    }

    suspend fun insertFile(file: ProjectFileEntity) = projectFileDao.insertFile(file)
    suspend fun insertFiles(files: List<ProjectFileEntity>) = projectFileDao.insertFiles(files)
    suspend fun updateFile(file: ProjectFileEntity) = projectFileDao.updateFile(file)
    suspend fun deleteFile(fileId: String) = projectFileDao.deleteFileById(fileId)

    suspend fun insertMemory(type: String, title: String, content: String, tags: String) {
        val memory = MemoryEntity(
            id = UUID.randomUUID().toString(),
            memoryType = type,
            title = title,
            content = content,
            tags = tags
        )
        memoryDao.insertMemory(memory)
    }

    suspend fun deleteMemory(id: String) = memoryDao.deleteMemoryById(id)

    suspend fun logAudit(agentId: String, action: String, permissionLevel: Int, approved: Boolean, details: String) {
        val log = AuditLogEntity(
            id = UUID.randomUUID().toString(),
            agentId = agentId,
            action = action,
            permissionLevel = permissionLevel,
            approved = approved,
            details = details
        )
        auditLogDao.insertAuditLog(log)
    }

    suspend fun seedInitialDataIfEmpty() {
        val defaultProjectId = "proj-chatx-001"
        val existing = projectDao.getProjectById(defaultProjectId)
        if (existing == null) {
            val sampleProject = ProjectEntity(
                id = defaultProjectId,
                name = "ChatX Android",
                techStack = "Kotlin / Jetpack Compose",
                description = "Real-time AI-powered secure chat application with end-to-end encryption, voice notes, and media sharing.",
                status = "READY",
                architectureJson = "{\"modules\": [\"ui\", \"data\", \"domain\", \"network\"], \"database\": \"Room\", \"state\": \"Flow\"}",
                buildStatus = "SUCCESS",
                gitCommitHash = "git-a8f12c"
            )
            projectDao.insertProject(sampleProject)

            val sampleFiles = listOf(
                ProjectFileEntity(
                    id = "file-001",
                    projectId = defaultProjectId,
                    filePath = "app/src/main/java/com/chatx/MainActivity.kt",
                    fileName = "MainActivity.kt",
                    language = "kotlin",
                    fileContent = """
package com.chatx

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import com.chatx.ui.ChatScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                ChatScreen()
            }
        }
    }
}
                    """.trimIndent()
                ),
                ProjectFileEntity(
                    id = "file-002",
                    projectId = defaultProjectId,
                    filePath = "app/src/main/java/com/chatx/ui/ChatScreen.kt",
                    fileName = "ChatScreen.kt",
                    language = "kotlin",
                    fileContent = """
package com.chatx.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun ChatScreen() {
    var textState by remember { mutableStateOf("") }
    val messages = remember { mutableStateListOf("Welcome to ChatX!", "Built with PAIOS Autonomous Engineer.") }

    Scaffold(
        topBar = { TopAppBar(title = { Text("ChatX Messenger") }) },
        bottomBar = {
            Row(modifier = Modifier.padding(8.dp).fillMaxWidth()) {
                TextField(
                    value = textState,
                    onValueChange = { textState = it },
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Type message...") }
                )
                Spacer(Modifier.width(8.dp))
                Button(onClick = {
                    if (textState.isNotBlank()) {
                        messages.add(textState)
                        textState = ""
                    }
                }) { Text("Send") }
            }
        }
    ) { padding ->
        LazyColumn(modifier = Modifier.padding(padding).fillMaxSize()) {
            items(messages) { msg ->
                Card(modifier = Modifier.padding(8.dp).fillMaxWidth()) {
                    Text(msg, modifier = Modifier.padding(12.dp))
                }
            }
        }
    }
}
                    """.trimIndent()
                ),
                ProjectFileEntity(
                    id = "file-003",
                    projectId = defaultProjectId,
                    filePath = "app/src/test/java/com/chatx/ChatUnitTest.kt",
                    fileName = "ChatUnitTest.kt",
                    language = "kotlin",
                    fileContent = """
package com.chatx

import org.junit.Test
import org.junit.Assert.*

class ChatUnitTest {
    @Test
    fun testMessageValidation() {
        val validMsg = "Hello World"
        assertTrue(validMsg.isNotBlank())
    }

    @Test
    fun testEncryptionKeyGeneration() {
        val key = "SECURE_KEY_PAIOS_123"
        assertEquals(20, key.length)
    }
}
                    """.trimIndent()
                ),
                ProjectFileEntity(
                    id = "file-004",
                    projectId = defaultProjectId,
                    filePath = "README.md",
                    fileName = "README.md",
                    language = "markdown",
                    fileContent = """
# ChatX Messenger
Built autonomously by **PAIOS (Personal AI Operating System)**.

## Features
- Jetpack Compose M3 UI
- Clean MVVM Architecture
- Room local message cache
- WebSocket Real-time sync
- Automated Unit Tests Passing (2/2)
                    """.trimIndent()
                )
            )
            projectFileDao.insertFiles(sampleFiles)

            // Seed initial memories
            insertMemory(
                "USER_PREFERENCE",
                "UI Styling Preference",
                "User prefers modern Cyber Dark themes with neon accents and clean Kotlin Jetpack Compose code structure.",
                "ui,theme,preferences"
            )
            insertMemory(
                "PROJECT_LEARNING",
                "Architecture Standard",
                "Always generate modular Clean Architecture: ui, domain, data layers with Room persistence.",
                "architecture,standards"
            )
            insertMemory(
                "LONG_TERM",
                "User Language Preference",
                "User communicates in both Urdu (اردو) and English. Support natural language in both languages.",
                "language,urdu,english"
            )

            // Initial Audit Log
            logAudit(
                "master_agent",
                "PAIOS Core Initialization",
                1,
                true,
                "Operating System booted successfully. 14 Specialist Agents loaded into memory."
            )
        }
    }
}
