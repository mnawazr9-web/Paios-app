package com.example.paios.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "projects")
data class ProjectEntity(
    @PrimaryKey val id: String,
    val name: String,
    val techStack: String, // e.g. "Kotlin / Jetpack Compose", "Python / FastAPI", "Flutter / Dart", "React / TypeScript"
    val description: String,
    val status: String, // "PLANNING", "CODING", "TESTING", "BUILDING", "READY"
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val architectureJson: String = "",
    val buildStatus: String = "SUCCESS",
    val gitCommitHash: String = "init-c1042"
)

@Entity(tableName = "project_files")
data class ProjectFileEntity(
    @PrimaryKey val id: String,
    val projectId: String,
    val filePath: String,
    val fileName: String,
    val fileContent: String,
    val language: String, // "kotlin", "python", "javascript", "typescript", "dart", "json", "markdown", "xml"
    val isModified: Boolean = false,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "memories")
data class MemoryEntity(
    @PrimaryKey val id: String,
    val memoryType: String, // "SHORT_TERM", "LONG_TERM", "USER_PREFERENCE", "PROJECT_LEARNING"
    val title: String,
    val content: String,
    val tags: String,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey val id: String,
    val timestamp: Long = System.currentTimeMillis(),
    val agentId: String,
    val action: String,
    val permissionLevel: Int,
    val approved: Boolean,
    val details: String
)
