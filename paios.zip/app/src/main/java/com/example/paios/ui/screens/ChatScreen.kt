package com.example.paios.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.paios.model.*
import com.example.paios.ui.components.VoiceWaveformBar
import com.example.paios.ui.components.WorkflowProgressCard
import com.example.ui.theme.*

@Composable
fun ChatScreen(
    messages: List<ChatMessage>,
    activeStep: WorkflowStep,
    isGenerating: Boolean,
    isListening: Boolean,
    isSpeaking: Boolean,
    onSendMessage: (String) -> Unit,
    onToggleListen: () -> Unit,
    onStopSpeak: () -> Unit,
    onNavigateToIde: () -> Unit,
    modifier: Modifier = Modifier
) {
    var inputText by remember { mutableStateOf("") }
    val listState = rememberLazyListState()

    // Auto-scroll to bottom on new messages
    LaunchedEffect(messages.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    val quickPrompts = listOf(
        "🦙 علامہ لوکل ماڈل چلاؤ (بغیر انٹرنیٹ)" to "Run Allama Local Model 100% Offline",
        "🚀 میرے لیے ایک Chat App بناؤ" to "Create a real-time Chat App with Room and Compose",
        "🌐 YouTube کھولو اور ویڈیوز تلاش کرو" to "Open YouTube and search for Flutter tutorials",
        "💻 VS Code اور میرا Project کھولو" to "Open VS Code developer environment",
        "🧪 تمام Tests چلاؤ اور Errors Fix کرو" to "Run all unit tests and auto-fix any errors",
        "📋 PAIOS سسٹم اسٹیٹس اور میموری بتاؤ" to "Show system status, active agents, and memory"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBackground)
    ) {
        // Voice Waveform & Mic Bar
        VoiceWaveformBar(
            isListening = isListening,
            isSpeaking = isSpeaking,
            onToggleListen = onToggleListen,
            onStopSpeak = onStopSpeak
        )

        // Workflow Progress Card (When Autonomous Engineer is Active)
        if (activeStep != WorkflowStep.IDLE) {
            WorkflowProgressCard(
                currentStep = activeStep,
                modifier = Modifier.padding(horizontal = 16.dp)
            )
        }

        // Messages Stream
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { Spacer(Modifier.height(8.dp)) }

            items(messages) { message ->
                MessageBubble(
                    message = message,
                    onNavigateToIde = onNavigateToIde
                )
            }

            if (isGenerating) {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(
                            color = CyberCyan,
                            modifier = Modifier.size(18.dp),
                            strokeWidth = 2.dp
                        )
                        Spacer(Modifier.width(10.dp))
                        Text(
                            text = "PAIOS Agent reasoning & executing...",
                            style = MaterialTheme.typography.bodySmall,
                            color = CyberTextSecondary
                        )
                    }
                }
            }

            item { Spacer(Modifier.height(8.dp)) }
        }

        // Quick Suggestion Chips
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(quickPrompts) { (urduPrompt, engAction) ->
                Surface(
                    color = CyberSurfaceVariant,
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, CyberBorder),
                    modifier = Modifier
                        .clip(RoundedCornerShape(16.dp))
                        .clickable { onSendMessage(urduPrompt) }
                ) {
                    Text(
                        text = urduPrompt,
                        style = MaterialTheme.typography.labelSmall,
                        color = CyberTextPrimary,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        fontSize = 11.sp
                    )
                }
            }
        }

        // Input Field Bar
        Surface(
            color = CyberSurface,
            border = BorderStroke(1.dp, CyberBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = inputText,
                    onValueChange = { inputText = it },
                    placeholder = {
                        Text(
                            "اردو یا English میں حکم دیں... (e.g. Chat App بناؤ)",
                            style = MaterialTheme.typography.bodyMedium,
                            color = CyberTextTertiary,
                            fontSize = 12.sp
                        )
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = CyberCyan,
                        unfocusedBorderColor = CyberBorder,
                        focusedTextColor = CyberTextPrimary,
                        unfocusedTextColor = CyberTextPrimary,
                        cursorColor = CyberCyan
                    ),
                    shape = RoundedCornerShape(24.dp),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("chat_input_field")
                )

                Spacer(Modifier.width(8.dp))

                IconButton(
                    onClick = {
                        if (inputText.isNotBlank()) {
                            onSendMessage(inputText)
                            inputText = ""
                        }
                    },
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(listOf(CyberCyan, CyberBlue))
                        )
                        .testTag("chat_send_button")
                ) {
                    Icon(
                        Icons.Default.Send,
                        contentDescription = "Send",
                        tint = CyberBackground,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun MessageBubble(
    message: ChatMessage,
    onNavigateToIde: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isUser = message.role == MessageRole.USER
    val isAlert = message.role == MessageRole.SECURITY_ALERT

    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
    ) {
        // Agent Badge
        if (!isUser) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(bottom = 4.dp, start = 4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(if (isAlert) CyberCrimson else message.agent.badgeColor)
                )
                Spacer(Modifier.width(6.dp))
                Text(
                    text = "${message.agent.title} (${message.agent.titleUrdu})",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.Bold,
                    color = if (isAlert) CyberCrimson else message.agent.badgeColor,
                    fontSize = 10.sp
                )

                if (message.isOfflineGenerated) {
                    Spacer(Modifier.width(6.dp))
                    Surface(
                        color = CyberGreen.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "🦙 ALLAMA OFFLINE",
                            color = CyberGreen,
                            fontSize = 8.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                }
            }
        }

        Surface(
            color = when {
                isUser -> CyberCyan.copy(alpha = 0.2f)
                isAlert -> CyberCrimson.copy(alpha = 0.15f)
                else -> CyberSurfaceElevated
            },
            shape = RoundedCornerShape(
                topStart = 16.dp,
                topEnd = 16.dp,
                bottomStart = if (isUser) 16.dp else 4.dp,
                bottomEnd = if (isUser) 4.dp else 16.dp
            ),
            border = BorderStroke(
                1.dp,
                when {
                    isUser -> CyberCyan.copy(alpha = 0.5f)
                    isAlert -> CyberCrimson
                    else -> CyberBorder
                }
            ),
            modifier = Modifier.widthIn(max = 340.dp)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    text = message.text,
                    style = MaterialTheme.typography.bodyMedium,
                    color = if (isAlert) CyberCrimson else CyberTextPrimary,
                    lineHeight = 20.sp
                )

                // If Code or Project was created, provide Quick Action Button
                if (message.workflowStep == WorkflowStep.COMPLETED || message.text.contains("Project IDE") || message.text.contains("پروجیکٹ")) {
                    Spacer(Modifier.height(10.dp))
                    Button(
                        onClick = onNavigateToIde,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = CyberCyan,
                            contentColor = CyberBackground
                        ),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("open_project_ide_button")
                    ) {
                        Icon(Icons.Default.Code, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("OPEN IN PROJECT IDE (پروجیکٹ کھولیں)", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
