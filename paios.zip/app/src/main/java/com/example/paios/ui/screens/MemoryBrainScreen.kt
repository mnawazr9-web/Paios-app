package com.example.paios.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.paios.data.local.AuditLogEntity
import com.example.paios.data.local.MemoryEntity
import com.example.paios.model.*
import com.example.ui.theme.*

enum class BrainSubTab(val title: String, val titleUrdu: String, val icon: String) {
    ALLAMA("Allama Local LLM", "علامہ لوکل ماڈل", "allama"),
    MEMORY("Memory & Knowledge", "یادداشت و ترجیحات", "memory"),
    MODELS("AI Modes & Cloud", "موڈز و انجن", "models"),
    SECURITY("Security & Audit", "سیکیورٹی و لاگز", "security")
}

@Composable
fun MemoryBrainScreen(
    metrics: SystemMetrics,
    memories: List<MemoryEntity>,
    auditLogs: List<AuditLogEntity>,
    ollamaConfig: OllamaConfig,
    localModels: List<LocalModelInfo>,
    latestBenchmark: LocalBenchmarkResult?,
    isTestingConnection: Boolean,
    downloadingModelId: String?,
    onAddMemory: (String, String, String, String) -> Unit,
    onDeleteMemory: (String) -> Unit,
    onSetAiMode: (AiOperationMode) -> Unit,
    onSetModel: (String) -> Unit,
    onUpdateOllamaConfig: (OllamaConfig) -> Unit,
    onTestOllamaConnection: () -> Unit,
    onActivateLocalModel: (String) -> Unit,
    onDownloadLocalModel: (String) -> Unit,
    onRunLocalBenchmark: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var currentSubTab by remember { mutableStateOf(BrainSubTab.ALLAMA) }
    var showAddMemoryDialog by remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBackground)
            .padding(12.dp)
    ) {
        // Sub Tab Selector
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(CyberSurface)
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            BrainSubTab.entries.forEach { tab ->
                val isSelected = currentSubTab == tab
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isSelected) CyberCyan.copy(alpha = 0.2f) else Color.Transparent,
                    border = if (isSelected) BorderStroke(1.dp, CyberCyan) else null,
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { currentSubTab = tab }
                ) {
                    Column(
                        modifier = Modifier.padding(vertical = 8.dp, horizontal = 2.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = tab.title,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) CyberCyan else CyberTextSecondary,
                            fontSize = 9.5.sp,
                            maxLines = 1
                        )
                        Text(
                            text = tab.titleUrdu,
                            style = MaterialTheme.typography.labelSmall,
                            color = if (isSelected) CyberCyan.copy(alpha = 0.8f) else CyberTextTertiary,
                            fontSize = 8.sp,
                            maxLines = 1
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(10.dp))

        when (currentSubTab) {
            BrainSubTab.ALLAMA -> {
                AllamaLocalModelHubView(
                    config = ollamaConfig,
                    models = localModels,
                    latestBenchmark = latestBenchmark,
                    isTestingConnection = isTestingConnection,
                    downloadingModelId = downloadingModelId,
                    activeMode = metrics.activeMode,
                    onSwitchToOfflineMode = { onSetAiMode(AiOperationMode.OFFLINE_ALLAMA) },
                    onUpdateConfig = onUpdateOllamaConfig,
                    onTestConnection = onTestOllamaConnection,
                    onActivateModel = onActivateLocalModel,
                    onDownloadModel = onDownloadLocalModel,
                    onRunBenchmark = onRunLocalBenchmark
                )
            }

            BrainSubTab.MEMORY -> {
                Column(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "Persistent Memory Store (Room DB)",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = CyberTextPrimary
                            )
                            Text(
                                text = "User preferences, coding standards & project learnings.",
                                style = MaterialTheme.typography.bodySmall,
                                color = CyberTextSecondary
                            )
                        }

                        Button(
                            onClick = { showAddMemoryDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = CyberBackground),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.height(32.dp).testTag("add_memory_button")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("ADD MEMORY", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(Modifier.height(10.dp))

                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        items(memories) { memory ->
                            Surface(
                                color = CyberSurfaceElevated,
                                shape = RoundedCornerShape(10.dp),
                                border = BorderStroke(1.dp, CyberBorder),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Surface(
                                            color = CyberCyan.copy(alpha = 0.15f),
                                            shape = RoundedCornerShape(4.dp)
                                        ) {
                                            Text(
                                                text = memory.memoryType,
                                                color = CyberCyan,
                                                style = MaterialTheme.typography.labelSmall,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 9.sp,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }

                                        IconButton(
                                            onClick = { onDeleteMemory(memory.id) },
                                            modifier = Modifier.size(24.dp)
                                        ) {
                                            Icon(Icons.Default.Delete, contentDescription = "Delete", tint = CyberTextTertiary, modifier = Modifier.size(16.dp))
                                        }
                                    }

                                    Spacer(Modifier.height(4.dp))

                                    Text(
                                        text = memory.title,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = CyberTextPrimary
                                    )

                                    Spacer(Modifier.height(4.dp))

                                    Text(
                                        text = memory.content,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = CyberTextSecondary
                                    )

                                    if (memory.tags.isNotBlank()) {
                                        Spacer(Modifier.height(6.dp))
                                        Text(
                                            text = "Tags: ${memory.tags}",
                                            style = MaterialTheme.typography.labelSmall,
                                            color = CyberTextTertiary,
                                            fontSize = 9.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            BrainSubTab.MODELS -> {
                Column(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    Text(
                        text = "AI Brain & Multi-Model Engine",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = CyberTextPrimary
                    )
                    Text(
                        text = "Switch between Allama Local Model (Offline), Gemini Cloud, or Hybrid routing.",
                        style = MaterialTheme.typography.bodySmall,
                        color = CyberTextSecondary
                    )

                    Spacer(Modifier.height(14.dp))

                    Text("Operation Modes", style = MaterialTheme.typography.labelSmall, color = CyberTextSecondary, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))

                    AiOperationMode.entries.forEach { mode ->
                        val isSelected = metrics.activeMode == mode
                        Surface(
                            color = if (isSelected) CyberCyan.copy(alpha = 0.15f) else CyberSurfaceElevated,
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, if (isSelected) CyberCyan else CyberBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { onSetAiMode(mode) }
                        ) {
                            Row(
                                modifier = Modifier.padding(14.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(mode.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = if (isSelected) CyberCyan else CyberTextPrimary)
                                    Text(mode.titleUrdu, style = MaterialTheme.typography.bodySmall, color = CyberTextSecondary, fontSize = 11.sp)
                                    Text(mode.desc, style = MaterialTheme.typography.bodySmall, color = CyberTextTertiary, fontSize = 10.sp)
                                }
                                RadioButton(
                                    selected = isSelected,
                                    onClick = { onSetAiMode(mode) },
                                    colors = RadioButtonDefaults.colors(selectedColor = CyberCyan)
                                )
                            }
                        }
                    }

                    Spacer(Modifier.height(16.dp))

                    Text("Select Default Model (Cloud / Multi-modal)", style = MaterialTheme.typography.labelSmall, color = CyberTextSecondary, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(6.dp))

                    val models = listOf(
                        "allama-llama3.2-3b" to "Allama Local LLM - 100% Offline Edge Model",
                        "gemini-3.5-flash" to "Google Cloud - Fastest Multimodal & Autonomous Coding",
                        "gemini-3.1-pro-preview" to "Google Cloud - Complex Reasoning & Multi-step Architecture"
                    )

                    models.forEach { (modelId, desc) ->
                        val isSelected = metrics.selectedModel == modelId
                        Surface(
                            color = if (isSelected) CyberElectric.copy(alpha = 0.15f) else CyberSurfaceElevated,
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, if (isSelected) CyberElectric else CyberBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { onSetModel(modelId) }
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(modelId, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, color = if (isSelected) CyberElectric else CyberTextPrimary, fontSize = 12.sp)
                                    Text(desc, style = MaterialTheme.typography.bodySmall, color = CyberTextSecondary, fontSize = 10.sp)
                                }
                                RadioButton(
                                    selected = isSelected,
                                    onClick = { onSetModel(modelId) },
                                    colors = RadioButtonDefaults.colors(selectedColor = CyberElectric)
                                )
                            }
                        }
                    }
                }
            }

            BrainSubTab.SECURITY -> {
                Column(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    Text(
                        text = "PAIOS Security & Audit Logs",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = CyberTextPrimary
                    )
                    Text(
                        text = "5-Level permission hierarchy with real-time audit ledger.",
                        style = MaterialTheme.typography.bodySmall,
                        color = CyberTextSecondary
                    )

                    Spacer(Modifier.height(10.dp))

                    LazyColumn(
                        verticalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        item {
                            Text("Recent System Audit Logs", style = MaterialTheme.typography.labelSmall, color = CyberTextSecondary, fontWeight = FontWeight.Bold)
                        }

                        items(auditLogs) { log ->
                            val perm = PermissionLevel.fromLevel(log.permissionLevel)
                            Surface(
                                color = CyberSurfaceElevated,
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, CyberBorder),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column(modifier = Modifier.weight(1f)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Surface(
                                                color = perm.color.copy(alpha = 0.2f),
                                                shape = RoundedCornerShape(4.dp)
                                            ) {
                                                Text("L${log.permissionLevel}", color = perm.color, fontWeight = FontWeight.Bold, fontSize = 9.sp, modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp))
                                            }
                                            Spacer(Modifier.width(6.dp))
                                            Text(log.agentId, style = MaterialTheme.typography.labelSmall, color = CyberCyan, fontSize = 10.sp)
                                            Spacer(Modifier.width(6.dp))
                                            Text(log.action, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold, color = CyberTextPrimary, fontSize = 11.sp)
                                        }
                                        Spacer(Modifier.height(2.dp))
                                        Text(log.details, style = MaterialTheme.typography.bodySmall, color = CyberTextSecondary, fontSize = 10.sp)
                                    }

                                    Icon(
                                        imageVector = if (log.approved) Icons.Default.CheckCircle else Icons.Default.Cancel,
                                        contentDescription = null,
                                        tint = if (log.approved) CyberGreen else CyberCrimson,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Add Memory Dialog
    if (showAddMemoryDialog) {
        var memTitle by remember { mutableStateOf("") }
        var memContent by remember { mutableStateOf("") }
        var memType by remember { mutableStateOf("USER_PREFERENCE") }
        var memTags by remember { mutableStateOf("") }

        Dialog(onDismissRequest = { showAddMemoryDialog = false }) {
            Surface(
                color = CyberSurface,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, CyberCyan),
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text("🧠 Add Knowledge / Memory", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = CyberCyan)
                    Spacer(Modifier.height(12.dp))

                    OutlinedTextField(
                        value = memTitle,
                        onValueChange = { memTitle = it },
                        label = { Text("Memory Title") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(Modifier.height(10.dp))

                    OutlinedTextField(
                        value = memContent,
                        onValueChange = { memContent = it },
                        label = { Text("Details / Preference") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(Modifier.height(10.dp))

                    OutlinedTextField(
                        value = memTags,
                        onValueChange = { memTags = it },
                        label = { Text("Tags (comma separated)") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(Modifier.height(16.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { showAddMemoryDialog = false }, modifier = Modifier.weight(1f)) {
                            Text("CANCEL")
                        }
                        Button(
                            onClick = {
                                if (memTitle.isNotBlank() && memContent.isNotBlank()) {
                                    onAddMemory(memType, memTitle, memContent, memTags)
                                    showAddMemoryDialog = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = CyberBackground),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("SAVE MEMORY", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun AllamaLocalModelHubView(
    config: OllamaConfig,
    models: List<LocalModelInfo>,
    latestBenchmark: LocalBenchmarkResult?,
    isTestingConnection: Boolean,
    downloadingModelId: String?,
    activeMode: AiOperationMode,
    onSwitchToOfflineMode: () -> Unit,
    onUpdateConfig: (OllamaConfig) -> Unit,
    onTestConnection: () -> Unit,
    onActivateModel: (String) -> Unit,
    onDownloadModel: (String) -> Unit,
    onRunBenchmark: (String) -> Unit
) {
    var serverHostInput by remember { mutableStateOf(config.serverHost) }
    val isOfflineModeActive = activeMode == AiOperationMode.OFFLINE_ALLAMA

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Air-Gapped Offline HUD Banner
        item {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = if (isOfflineModeActive) CyberGreen.copy(alpha = 0.12f) else CyberSurfaceElevated,
                border = BorderStroke(1.dp, if (isOfflineModeActive) CyberGreen else CyberBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(if (isOfflineModeActive) CyberGreen else CyberAmber)
                            )
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = if (isOfflineModeActive) "100% OFFLINE ALLAMA ACTIVE" else "ALLAMA LOCAL ENGINE READY",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Black,
                                color = if (isOfflineModeActive) CyberGreen else CyberAmber,
                                letterSpacing = 1.sp
                            )
                        }

                        if (!isOfflineModeActive) {
                            Button(
                                onClick = onSwitchToOfflineMode,
                                colors = ButtonDefaults.buttonColors(containerColor = CyberGreen, contentColor = CyberBackground),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                                modifier = Modifier.height(28.dp)
                            ) {
                                Text("ACTIVATE OFFLINE", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(Modifier.height(6.dp))

                    Text(
                        text = "علامہ لوکل ماڈل انٹرنیٹ کے بغیر 100% خودکار کام کرتا ہے۔ سارا ڈیٹا آپ کی ڈیوائس پر ہی پروسیس ہوتا ہے (Zero Internet / Air-Gapped Privacy)۔",
                        style = MaterialTheme.typography.bodySmall,
                        color = CyberTextSecondary,
                        fontSize = 11.sp
                    )

                    Spacer(Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Surface(
                            color = CyberSurface,
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text("Active Model", color = CyberTextTertiary, fontSize = 9.sp)
                                Text(config.activeModelId, color = CyberCyan, fontWeight = FontWeight.Bold, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                            }
                        }

                        Surface(
                            color = CyberSurface,
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text("Local Speed", color = CyberTextTertiary, fontSize = 9.sp)
                                Text("~48.6 tokens/s", color = CyberGreen, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                        }

                        Surface(
                            color = CyberSurface,
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text("Data Egress", color = CyberTextTertiary, fontSize = 9.sp)
                                Text("0.0 KB (Offline)", color = CyberElectric, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }

        // Ollama Local Server / Host Configurator
        item {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = CyberSurfaceElevated,
                border = BorderStroke(1.dp, CyberBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "🔌 Ollama Local Server & Host Endpoint",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = CyberTextPrimary
                    )
                    Text(
                        text = "Connect to Ollama service running on device localhost or network IP.",
                        style = MaterialTheme.typography.bodySmall,
                        color = CyberTextSecondary,
                        fontSize = 10.sp
                    )

                    Spacer(Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = serverHostInput,
                            onValueChange = {
                                serverHostInput = it
                                onUpdateConfig(config.copy(serverHost = it))
                            },
                            modifier = Modifier.weight(1f),
                            label = { Text("Ollama Endpoint") },
                            singleLine = true,
                            textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace)
                        )

                        Button(
                            onClick = onTestConnection,
                            enabled = !isTestingConnection,
                            colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = CyberBackground),
                            modifier = Modifier.height(52.dp)
                        ) {
                            if (isTestingConnection) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), color = CyberBackground, strokeWidth = 2.dp)
                            } else {
                                Text("TEST HOST", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Standard: http://localhost:11434  |  Emulator: http://10.0.2.2:11434",
                            style = MaterialTheme.typography.labelSmall,
                            color = CyberTextTertiary,
                            fontSize = 8.5.sp
                        )

                        Surface(
                            color = CyberGreen.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(4.dp)
                        ) {
                            Text(
                                text = "Local Brain Active",
                                color = CyberGreen,
                                fontSize = 8.5.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }

        // Local Models Catalog
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "🦙 Available Allama Local Models",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = CyberTextPrimary
                )
                Text(
                    text = "${models.size} Models in Registry",
                    style = MaterialTheme.typography.labelSmall,
                    color = CyberTextTertiary,
                    fontSize = 10.sp
                )
            }
        }

        items(models) { model ->
            val isActive = config.activeModelId == model.id
            val isDownloading = downloadingModelId == model.id

            Surface(
                color = if (isActive) CyberCyan.copy(alpha = 0.08f) else CyberSurfaceElevated,
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, if (isActive) CyberCyan else CyberBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = model.name,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = if (isActive) CyberCyan else CyberTextPrimary
                                )
                                if (isActive) {
                                    Spacer(Modifier.width(6.dp))
                                    Surface(
                                        color = CyberCyan.copy(alpha = 0.2f),
                                        shape = RoundedCornerShape(4.dp)
                                    ) {
                                        Text("ACTIVE IN RAM", color = CyberCyan, fontWeight = FontWeight.Black, fontSize = 8.sp, modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp))
                                    }
                                }
                            }
                            Text(
                                text = model.descriptionUrdu,
                                style = MaterialTheme.typography.bodySmall,
                                color = CyberTextSecondary,
                                fontSize = 10.sp
                            )
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            if (!model.isDownloaded) {
                                Button(
                                    onClick = { onDownloadModel(model.id) },
                                    enabled = !isDownloading,
                                    colors = ButtonDefaults.buttonColors(containerColor = CyberElectric, contentColor = Color.White),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(28.dp)
                                ) {
                                    if (isDownloading) {
                                        CircularProgressIndicator(modifier = Modifier.size(12.dp), color = Color.White, strokeWidth = 1.5.dp)
                                    } else {
                                        Text("DOWNLOAD", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            } else {
                                Button(
                                    onClick = { onActivateModel(model.id) },
                                    enabled = !isActive,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isActive) CyberSurface else CyberCyan,
                                        contentColor = if (isActive) CyberCyan else CyberBackground
                                    ),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                    modifier = Modifier.height(28.dp)
                                ) {
                                    Text(if (isActive) "LOADED" else "ACTIVATE", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }

                    Spacer(Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(color = CyberSurface, shape = RoundedCornerShape(4.dp), modifier = Modifier.padding(vertical = 2.dp)) {
                            Text("Params: ${model.parameterSize}", color = CyberTextTertiary, fontSize = 9.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                        }
                        Surface(color = CyberSurface, shape = RoundedCornerShape(4.dp), modifier = Modifier.padding(vertical = 2.dp)) {
                            Text("Quant: ${model.quantization}", color = CyberTextTertiary, fontSize = 9.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                        }
                        Surface(color = CyberSurface, shape = RoundedCornerShape(4.dp), modifier = Modifier.padding(vertical = 2.dp)) {
                            Text("Disk: ${model.diskSize}", color = CyberTextTertiary, fontSize = 9.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                        }
                        Surface(color = CyberSurface, shape = RoundedCornerShape(4.dp), modifier = Modifier.padding(vertical = 2.dp)) {
                            Text("RAM: ${model.ramRequiredMb}MB", color = CyberTextTertiary, fontSize = 9.sp, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                        }
                    }
                }
            }
        }

        // Benchmark Tester & Performance
        item {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = CyberSurfaceElevated,
                border = BorderStroke(1.dp, CyberBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("⚡ On-Device Benchmark Tester", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = CyberTextPrimary)
                            Text("Test local tokens/sec & RAM throughput.", style = MaterialTheme.typography.bodySmall, color = CyberTextSecondary, fontSize = 10.sp)
                        }

                        Button(
                            onClick = { onRunBenchmark(config.activeModelId) },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberGreen, contentColor = CyberBackground),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier.height(30.dp)
                        ) {
                            Text("RUN TEST", fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    latestBenchmark?.let { bm ->
                        Spacer(Modifier.height(10.dp))
                        Surface(
                            color = CyberBackground,
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, CyberGreen.copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                horizontalArrangement = Arrangement.SpaceAround,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("GENERATION SPEED", color = CyberTextTertiary, fontSize = 8.sp)
                                    Text("${bm.tokensPerSecond} TPS", color = CyberGreen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("INFERENCE TIME", color = CyberTextTertiary, fontSize = 8.sp)
                                    Text("${bm.totalTimeMs} ms", color = CyberCyan, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Text("RAM OCCUPANCY", color = CyberTextTertiary, fontSize = 8.sp)
                                    Text("${bm.ramUsedMb} MB", color = CyberElectric, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        // Local Inference Parameters & Tuning
        item {
            Surface(
                shape = RoundedCornerShape(12.dp),
                color = CyberSurfaceElevated,
                border = BorderStroke(1.dp, CyberBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "🎛️ Local Inference Parameters",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = CyberTextPrimary
                    )

                    Spacer(Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Temperature (${String.format("%.1f", config.temperature)})", style = MaterialTheme.typography.bodySmall, color = CyberTextSecondary)
                        Slider(
                            value = config.temperature,
                            onValueChange = { onUpdateConfig(config.copy(temperature = it)) },
                            valueRange = 0.1f..1.0f,
                            modifier = Modifier.width(180.dp),
                            colors = SliderDefaults.colors(thumbColor = CyberCyan, activeTrackColor = CyberCyan)
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Context Window: ${config.contextWindow} tokens", style = MaterialTheme.typography.bodySmall, color = CyberTextSecondary)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            listOf(2048, 4096, 8192).forEach { ctx ->
                                val isCtxSelected = config.contextWindow == ctx
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = if (isCtxSelected) CyberCyan else CyberSurface,
                                    modifier = Modifier.clip(RoundedCornerShape(4.dp)).clickable { onUpdateConfig(config.copy(contextWindow = ctx)) }
                                ) {
                                    Text(
                                        "${ctx / 1024}K",
                                        color = if (isCtxSelected) CyberBackground else CyberTextSecondary,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
            Spacer(Modifier.height(20.dp))
        }
    }
}
