package com.example.paios.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.paios.data.local.ProjectFileEntity
import com.example.ui.theme.*

@Composable
fun CodeEditorView(
    file: ProjectFileEntity?,
    onSaveContent: (String) -> Unit,
    onRunCode: (String, String) -> Unit,
    onDeleteFile: (ProjectFileEntity) -> Unit,
    modifier: Modifier = Modifier
) {
    if (file == null) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(CyberSurface),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(
                    Icons.Default.Code,
                    contentDescription = null,
                    tint = CyberTextTertiary,
                    modifier = Modifier.size(48.dp)
                )
                Spacer(Modifier.height(8.dp))
                Text("Select a file from the explorer to view/edit code", color = CyberTextSecondary)
            }
        }
        return
    }

    var editableCode by remember(file.id) { mutableStateOf(file.fileContent) }
    var isEditing by remember { mutableStateOf(false) }
    val clipboardManager = LocalClipboardManager.current
    var copiedNotification by remember { mutableStateOf(false) }

    Surface(
        color = TerminalBlack,
        shape = RoundedCornerShape(8.dp),
        border = BorderStroke(1.dp, CyberBorder),
        modifier = modifier.fillMaxSize()
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Editor Toolbar
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CyberSurfaceVariant)
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = when (file.language) {
                            "kotlin" -> Icons.Default.IntegrationInstructions
                            "python" -> Icons.Default.Terminal
                            "markdown" -> Icons.Default.Description
                            else -> Icons.Default.Code
                        },
                        contentDescription = null,
                        tint = CyberCyan,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = file.fileName,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = CyberTextPrimary,
                        fontSize = 12.sp
                    )
                    if (file.isModified || editableCode != file.fileContent) {
                        Spacer(Modifier.width(6.dp))
                        Text("(modified)", color = CyberAmber, fontSize = 10.sp)
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    // Copy
                    IconButton(
                        onClick = {
                            clipboardManager.setText(AnnotatedString(editableCode))
                            copiedNotification = true
                        },
                        modifier = Modifier.size(30.dp)
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Copy", tint = CyberTextSecondary, modifier = Modifier.size(16.dp))
                    }

                    // Run
                    IconButton(
                        onClick = { onRunCode(editableCode, file.language) },
                        modifier = Modifier.size(30.dp)
                    ) {
                        Icon(Icons.Default.PlayArrow, contentDescription = "Run", tint = CyberGreen, modifier = Modifier.size(18.dp))
                    }

                    // Save
                    IconButton(
                        onClick = {
                            onSaveContent(editableCode)
                            isEditing = false
                        },
                        modifier = Modifier.size(30.dp).testTag("save_file_button")
                    ) {
                        Icon(Icons.Default.Save, contentDescription = "Save", tint = CyberCyan, modifier = Modifier.size(16.dp))
                    }

                    // Delete
                    IconButton(
                        onClick = { onDeleteFile(file) },
                        modifier = Modifier.size(30.dp)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = CyberCrimson, modifier = Modifier.size(16.dp))
                    }
                }
            }

            // Code Content with Line Numbers
            Row(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                val lines = editableCode.lines()
                val lineNumbersText = (1..lines.size).joinToString("\n")

                // Line Numbers Gutter
                Text(
                    text = lineNumbersText,
                    style = TextStyle(
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = CyberTextTertiary,
                        lineHeight = 18.sp
                    ),
                    modifier = Modifier
                        .background(CyberSurface.copy(alpha = 0.5f))
                        .padding(horizontal = 8.dp, vertical = 8.dp)
                )

                // Editable Code Field
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .padding(8.dp)
                        .horizontalScroll(rememberScrollState())
                ) {
                    BasicTextField(
                        value = editableCode,
                        onValueChange = {
                            editableCode = it
                            isEditing = true
                        },
                        textStyle = TextStyle(
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            color = CyberTextPrimary,
                            lineHeight = 18.sp
                        ),
                        cursorBrush = SolidColor(CyberCyan),
                        modifier = Modifier.fillMaxWidth().testTag("code_editor_input")
                    )
                }
            }
        }
    }
}
