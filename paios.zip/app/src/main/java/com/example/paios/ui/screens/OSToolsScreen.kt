package com.example.paios.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.paios.model.OSApplication
import com.example.paios.model.TerminalLog
import com.example.ui.theme.*

enum class OSTab(val title: String, val titleUrdu: String) {
    APPS("App Launcher", "ایپ لانچر"),
    TERMINAL("Terminal CLI", "ٹرمینل کمانڈ لائن"),
    BROWSER("Browser Automation", "براؤزر سرچ")
}

@Composable
fun OSToolsScreen(
    apps: List<OSApplication>,
    terminalLogs: List<TerminalLog>,
    onLaunchApp: (String, String?) -> Boolean,
    onRunTerminalCommand: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var currentSubTab by remember { mutableStateOf(OSTab.APPS) }
    var cliCommandInput by remember { mutableStateOf("") }
    var browserSearchQuery by remember { mutableStateOf("") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBackground)
            .padding(12.dp)
    ) {
        // Sub-Tab Switcher
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(10.dp))
                .background(CyberSurface)
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            OSTab.entries.forEach { tab ->
                val isSelected = currentSubTab == tab
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = if (isSelected) CyberCyan.copy(alpha = 0.2f) else Color.Transparent,
                    border = if (isSelected) BorderStroke(1.dp, CyberCyan) else null,
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(8.dp))
                        .clickable { currentSubTab = tab }
                ) {
                    Column(
                        modifier = Modifier.padding(vertical = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = tab.title,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) CyberCyan else CyberTextSecondary,
                            fontSize = 11.sp
                        )
                        Text(
                            text = tab.titleUrdu,
                            style = MaterialTheme.typography.bodySmall,
                            color = CyberTextTertiary,
                            fontSize = 9.sp
                        )
                    }
                }
            }
        }

        Spacer(Modifier.height(10.dp))

        // Content Area
        when (currentSubTab) {
            OSTab.APPS -> {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    item {
                        Text(
                            text = "Installed & Virtual System Applications",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = CyberTextPrimary,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                    }

                    items(apps) { app ->
                        Surface(
                            color = CyberSurfaceElevated,
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, CyberBorder),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        modifier = Modifier
                                            .size(36.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(CyberCyan.copy(alpha = 0.15f)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = when (app.iconName) {
                                                "chrome" -> Icons.Default.Language
                                                "youtube" -> Icons.Default.PlayCircleOutline
                                                "code" -> Icons.Default.Code
                                                "terminal" -> Icons.Default.Terminal
                                                "android" -> Icons.Default.PhoneAndroid
                                                "calc" -> Icons.Default.Calculate
                                                "folder" -> Icons.Default.Folder
                                                else -> Icons.Default.Apps
                                            },
                                            contentDescription = null,
                                            tint = CyberCyan,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    Spacer(Modifier.width(12.dp))
                                    Column {
                                        Text(app.name, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Bold, color = CyberTextPrimary)
                                        Text("${app.nameUrdu} • ${app.category}", style = MaterialTheme.typography.bodySmall, color = CyberTextTertiary, fontSize = 11.sp)
                                    }
                                }

                                Button(
                                    onClick = { onLaunchApp(app.id, null) },
                                    colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = CyberBackground),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                    modifier = Modifier.testTag("launch_app_${app.id}")
                                ) {
                                    Text("OPEN", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            OSTab.TERMINAL -> {
                Column(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    // Quick command chips
                    val quickCommands = listOf("ls", "git status", "gradle test", "gradle build", "whoami", "ps", "help")
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.padding(bottom = 8.dp)
                    ) {
                        items(quickCommands) { qCmd ->
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = CyberSurfaceVariant,
                                border = BorderStroke(1.dp, CyberBorder),
                                modifier = Modifier.clickable { onRunTerminalCommand(qCmd) }
                            ) {
                                Text(
                                    text = "$ $qCmd",
                                    fontFamily = FontFamily.Monospace,
                                    color = CyberCyan,
                                    fontSize = 11.sp,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    // Terminal View Box
                    Surface(
                        color = TerminalBlack,
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, CyberBorder),
                        modifier = Modifier.weight(1f).fillMaxWidth()
                    ) {
                        LazyColumn(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(12.dp),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            items(terminalLogs) { log ->
                                Column {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("paios@os:~$", color = CyberGreen, fontFamily = FontFamily.Monospace, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        Spacer(Modifier.width(6.dp))
                                        Text(log.command, color = Color.White, fontFamily = FontFamily.Monospace, fontSize = 11.sp)
                                    }
                                    if (log.output.isNotBlank()) {
                                        Spacer(Modifier.height(2.dp))
                                        Text(
                                            text = log.output,
                                            fontFamily = FontFamily.Monospace,
                                            color = if (log.isError) CyberCrimson else CyberTextSecondary,
                                            fontSize = 10.sp,
                                            lineHeight = 15.sp
                                        )
                                    }
                                }
                            }
                        }
                    }

                    Spacer(Modifier.height(8.dp))

                    // Terminal Input Prompt
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(CyberSurfaceElevated)
                            .padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("$", color = CyberGreen, fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.width(8.dp))
                        OutlinedTextField(
                            value = cliCommandInput,
                            onValueChange = { cliCommandInput = it },
                            placeholder = { Text("type command (e.g. ls, git status, help)...", fontSize = 11.sp, fontFamily = FontFamily.Monospace) },
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = Color.Transparent,
                                unfocusedBorderColor = Color.Transparent,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            textStyle = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Monospace, fontSize = 12.sp),
                            modifier = Modifier.weight(1f).testTag("terminal_cli_input")
                        )
                        IconButton(
                            onClick = {
                                if (cliCommandInput.isNotBlank()) {
                                    onRunTerminalCommand(cliCommandInput)
                                    cliCommandInput = ""
                                }
                            }
                        ) {
                            Icon(Icons.Default.KeyboardReturn, contentDescription = "Run", tint = CyberCyan)
                        }
                    }
                }
            }

            OSTab.BROWSER -> {
                Column(modifier = Modifier.weight(1f).fillMaxWidth()) {
                    Text(
                        text = "Browser & Video Search Automation",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = CyberTextPrimary
                    )
                    Text(
                        text = "Automate web browsing, search tutorials, documentation, and videos.",
                        style = MaterialTheme.typography.bodySmall,
                        color = CyberTextSecondary
                    )

                    Spacer(Modifier.height(14.dp))

                    OutlinedTextField(
                        value = browserSearchQuery,
                        onValueChange = { browserSearchQuery = it },
                        label = { Text("Search Query or URL") },
                        placeholder = { Text("e.g. Jetpack Compose tutorials, Android documentation") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = CyberCyan) },
                        modifier = Modifier.fillMaxWidth().testTag("browser_search_input")
                    )

                    Spacer(Modifier.height(12.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        Button(
                            onClick = {
                                onLaunchApp("app-chrome", if (browserSearchQuery.isNotBlank()) "https://www.google.com/search?q=${browserSearchQuery}" else "https://www.google.com")
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = CyberBackground),
                            modifier = Modifier.weight(1f).testTag("search_web_button")
                        ) {
                            Icon(Icons.Default.Language, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("SEARCH WEB", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                onLaunchApp("app-youtube", browserSearchQuery)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberCrimson, contentColor = Color.White),
                            modifier = Modifier.weight(1f).testTag("search_youtube_button")
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("YOUTUBE", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(Modifier.height(20.dp))

                    // Preset Bookmarks
                    Text("Developer Quick Links", style = MaterialTheme.typography.labelSmall, color = CyberTextSecondary, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    val bookmarks = listOf(
                        "Android Developer Docs" to "https://developer.android.com",
                        "Kotlin Language Docs" to "https://kotlinlang.org/docs",
                        "Google AI Studio" to "https://aistudio.google.com",
                        "GitHub Repositories" to "https://github.com"
                    )
                    bookmarks.forEach { (name, url) ->
                        Surface(
                            color = CyberSurfaceElevated,
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, CyberBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { onLaunchApp("app-chrome", url) }
                        ) {
                            Row(
                                modifier = Modifier.padding(12.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(name, color = CyberTextPrimary, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                    Text(url, color = CyberTextTertiary, fontSize = 10.sp)
                                }
                                Icon(Icons.Default.OpenInNew, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}
