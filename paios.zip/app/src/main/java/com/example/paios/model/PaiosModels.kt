package com.example.paios.model

enum class MessageRole {
    USER,
    ASSISTANT,
    SPECIALIST_AGENT,
    SYSTEM_LOG,
    TOOL_OUTPUT,
    SECURITY_ALERT
}

enum class AiOperationMode(val title: String, val titleUrdu: String, val desc: String) {
    OFFLINE_ALLAMA("Allama Local Model (Offline)", "علامہ لوکل ماڈل (بغیر انٹرنیٹ)", "100% Zero-Internet Local LLM & Ollama Neural Engine on-device"),
    ONLINE("Online (Gemini Cloud)", "آن لائن (کلاؤڈ جیمنی)", "High-performance multimodal reasoning & coding via Google Gemini API"),
    HYBRID("Hybrid (Smart Routing)", "ہائبرڈ (اسمارٹ روٹنگ)", "Routes sensitive data to Allama Local and heavy builds to Cloud")
}

data class LocalModelInfo(
    val id: String,
    val name: String,
    val parameterSize: String,
    val quantization: String,
    val diskSize: String,
    val ramRequiredMb: Int,
    val speedTps: Double,
    val isDownloaded: Boolean = true,
    val isLoadedInRam: Boolean = false,
    val description: String,
    val descriptionUrdu: String,
    val supportsCodeGeneration: Boolean = true,
    val supportsUrduReasoning: Boolean = true
)

data class OllamaConfig(
    val serverHost: String = "http://localhost:11434",
    val activeModelId: String = "llama3.2:3b",
    val temperature: Float = 0.7f,
    val contextWindow: Int = 4096,
    val cpuThreads: Int = 4,
    val gpuLayers: Int = 32,
    val isServerConnected: Boolean = true,
    val isAirGappedPrivacyMode: Boolean = true
)

data class LocalBenchmarkResult(
    val modelId: String,
    val promptTokens: Int,
    val generatedTokens: Int,
    val totalTimeMs: Long,
    val tokensPerSecond: Double,
    val ramUsedMb: Int,
    val timestamp: Long = System.currentTimeMillis()
)

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val text: String,
    val role: MessageRole = MessageRole.ASSISTANT,
    val agent: SpecialistAgent = SpecialistAgent.MASTER,
    val codeSnippet: String? = null,
    val codeLanguage: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val workflowStep: WorkflowStep? = null,
    val toolActionSummary: String? = null,
    val isEmergencyHalt: Boolean = false,
    val generatedByModel: String? = null,
    val isOfflineGenerated: Boolean = false
)

data class AgentState(
    val agent: SpecialistAgent,
    val isBusy: Boolean = false,
    val currentTask: String = "Idle",
    val completedCount: Int = 0,
    val loadPercentage: Int = 12
)

data class SystemMetrics(
    val cpuPercent: Int = 18,
    val ramUsedMb: Int = 1240,
    val ramTotalMb: Int = 4096,
    val batteryPercent: Int = 89,
    val isCharging: Boolean = true,
    val isOnline: Boolean = true,
    val activeMode: AiOperationMode = AiOperationMode.HYBRID,
    val selectedModel: String = "gemini-3.5-flash",
    val emergencyStopActive: Boolean = false,
    val uptimeSeconds: Long = 3600
)

data class OSApplication(
    val id: String,
    val name: String,
    val nameUrdu: String,
    val packageName: String,
    val category: String,
    val isRunning: Boolean = false,
    val iconName: String = "apps"
)

data class TestCaseResult(
    val name: String,
    val passed: Boolean,
    val durationMs: Long,
    val errorMessage: String? = null
)

data class TestReport(
    val totalTests: Int,
    val passedTests: Int,
    val failedTests: Int,
    val testCases: List<TestCaseResult>,
    val durationMs: Long,
    val summary: String
)

data class TerminalLog(
    val id: String = java.util.UUID.randomUUID().toString(),
    val command: String,
    val output: String,
    val isError: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

data class SecurityApprovalRequest(
    val requestId: String = java.util.UUID.randomUUID().toString(),
    val action: String,
    val actionUrdu: String,
    val agent: SpecialistAgent,
    val level: PermissionLevel,
    val details: String,
    val timestamp: Long = System.currentTimeMillis(),
    val onConfirm: () -> Unit,
    val onReject: () -> Unit
)
