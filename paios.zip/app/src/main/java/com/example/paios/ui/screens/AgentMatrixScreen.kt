package com.example.paios.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.paios.model.AgentState
import com.example.paios.model.SpecialistAgent
import com.example.ui.theme.*

@Composable
fun AgentMatrixScreen(
    agentsState: List<AgentState>,
    onDispatchTaskToAgent: (SpecialistAgent, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedAgentForDispatch by remember { mutableStateOf<SpecialistAgent?>(null) }
    var taskPromptInput by remember { mutableStateOf("") }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBackground)
            .padding(12.dp)
    ) {
        // Matrix Header
        Surface(
            color = CyberSurface,
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, CyberBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(14.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Hub, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = "14 Specialist AI Agents Matrix",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = CyberTextPrimary
                        )
                    }
                    Text(
                        text = "Real-time task distribution, load monitoring, and direct dispatch.",
                        style = MaterialTheme.typography.bodySmall,
                        color = CyberTextSecondary
                    )
                }

                Surface(
                    color = CyberGreen.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, CyberGreen)
                ) {
                    Text(
                        text = "14 ACTIVE",
                        color = CyberGreen,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        fontSize = 10.sp
                    )
                }
            }
        }

        Spacer(Modifier.height(10.dp))

        // Agents Grid
        LazyVerticalGrid(
            columns = GridCells.Adaptive(minSize = 160.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(agentsState) { state ->
                val agent = state.agent
                Surface(
                    color = CyberSurfaceElevated,
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(
                        1.dp,
                        if (state.isBusy) agent.badgeColor else CyberBorder
                    ),
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { selectedAgentForDispatch = agent }
                        .testTag("agent_card_${agent.id}")
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(28.dp)
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(agent.badgeColor.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = when (agent) {
                                        SpecialistAgent.MASTER -> Icons.Default.SmartToy
                                        SpecialistAgent.CODING -> Icons.Default.Code
                                        SpecialistAgent.DEBUGGING -> Icons.Default.BugReport
                                        SpecialistAgent.TESTING -> Icons.Default.CheckCircleOutline
                                        SpecialistAgent.UI_UX -> Icons.Default.Brush
                                        SpecialistAgent.PROJECT_MANAGER -> Icons.Default.Assignment
                                        SpecialistAgent.BROWSER -> Icons.Default.Language
                                        SpecialistAgent.FILE -> Icons.Default.Folder
                                        SpecialistAgent.TERMINAL -> Icons.Default.Terminal
                                        SpecialistAgent.OS_AUTOMATION -> Icons.Default.SettingsApplications
                                        SpecialistAgent.RESEARCH -> Icons.Default.FindInPage
                                        SpecialistAgent.DOCUMENTATION -> Icons.Default.Description
                                        SpecialistAgent.VOICE -> Icons.Default.RecordVoiceOver
                                        SpecialistAgent.VISION -> Icons.Default.Visibility
                                        SpecialistAgent.MEMORY -> Icons.Default.Psychology
                                    },
                                    contentDescription = null,
                                    tint = agent.badgeColor,
                                    modifier = Modifier.size(16.dp)
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(if (state.isBusy) CyberAmber else CyberGreen)
                            )
                        }

                        Spacer(Modifier.height(8.dp))

                        Text(
                            text = agent.title,
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = CyberTextPrimary,
                            fontSize = 12.sp
                        )

                        Text(
                            text = agent.titleUrdu,
                            style = MaterialTheme.typography.bodySmall,
                            color = agent.badgeColor,
                            fontSize = 10.sp
                        )

                        Spacer(Modifier.height(6.dp))

                        Text(
                            text = if (state.isBusy) state.currentTask else agent.roleDescription,
                            style = MaterialTheme.typography.bodySmall,
                            color = CyberTextSecondary,
                            fontSize = 10.sp,
                            maxLines = 2
                        )

                        Spacer(Modifier.height(8.dp))

                        // Load & Task count bar
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Load: ${state.loadPercentage}%",
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = FontFamily.Monospace,
                                color = if (state.loadPercentage > 50) CyberAmber else CyberTextTertiary,
                                fontSize = 9.sp
                            )
                            Text(
                                text = "Done: ${state.completedCount}",
                                style = MaterialTheme.typography.labelSmall,
                                fontFamily = FontFamily.Monospace,
                                color = CyberTextTertiary,
                                fontSize = 9.sp
                            )
                        }
                    }
                }
            }
        }
    }

    // Direct Dispatch Dialog
    if (selectedAgentForDispatch != null) {
        val agent = selectedAgentForDispatch!!
        Dialog(onDismissRequest = { selectedAgentForDispatch = null }) {
            Surface(
                color = CyberSurface,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, agent.badgeColor),
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(agent.badgeColor.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Send, contentDescription = null, tint = agent.badgeColor, modifier = Modifier.size(16.dp))
                        }
                        Spacer(Modifier.width(10.dp))
                        Column {
                            Text(agent.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = CyberTextPrimary)
                            Text(agent.titleUrdu, style = MaterialTheme.typography.bodySmall, color = agent.badgeColor)
                        }
                    }

                    Spacer(Modifier.height(10.dp))
                    Text(agent.roleDescription, style = MaterialTheme.typography.bodySmall, color = CyberTextSecondary)
                    Spacer(Modifier.height(14.dp))

                    OutlinedTextField(
                        value = taskPromptInput,
                        onValueChange = { taskPromptInput = it },
                        label = { Text("Enter prompt for ${agent.title}") },
                        placeholder = { Text("Explain task in Urdu or English...") },
                        modifier = Modifier.fillMaxWidth().testTag("dispatch_task_input")
                    )

                    Spacer(Modifier.height(16.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { selectedAgentForDispatch = null }, modifier = Modifier.weight(1f)) {
                            Text("CANCEL")
                        }
                        Button(
                            onClick = {
                                if (taskPromptInput.isNotBlank()) {
                                    onDispatchTaskToAgent(agent, taskPromptInput)
                                    taskPromptInput = ""
                                    selectedAgentForDispatch = null
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = agent.badgeColor, contentColor = CyberBackground),
                            modifier = Modifier.weight(1f).testTag("dispatch_submit_button")
                        ) {
                            Text("DISPATCH", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}
