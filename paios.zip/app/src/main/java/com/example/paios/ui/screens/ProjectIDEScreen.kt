package com.example.paios.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.paios.data.local.ProjectEntity
import com.example.paios.data.local.ProjectFileEntity
import com.example.paios.model.TestReport
import com.example.paios.ui.components.CodeEditorView
import com.example.ui.theme.*
import java.util.UUID

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProjectIDEScreen(
    projects: List<ProjectEntity>,
    activeProject: ProjectEntity?,
    files: List<ProjectFileEntity>,
    selectedFile: ProjectFileEntity?,
    testReport: TestReport?,
    onSelectProject: (ProjectEntity) -> Unit,
    onSelectFile: (ProjectFileEntity) -> Unit,
    onSaveFileContent: (String, String) -> Unit,
    onDeleteFile: (ProjectFileEntity) -> Unit,
    onCreateNewFile: (String, String, String, String) -> Unit,
    onRunCode: (String, String) -> Unit,
    onTriggerAutonomousBuild: (String) -> Unit,
    onRunTests: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showNewProjectDialog by remember { mutableStateOf(false) }
    var showNewFileDialog by remember { mutableStateOf(false) }
    var showTestDrawer by remember { mutableStateOf(false) }
    var consoleOutput by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(CyberBackground)
    ) {
        // Project Header Bar
        Surface(
            color = CyberSurface,
            border = BorderStroke(1.dp, CyberBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Project Name & Tech Badge
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.FolderSpecial, contentDescription = null, tint = CyberCyan, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(8.dp))
                            Text(
                                text = activeProject?.name ?: "Select / Create Project",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = CyberTextPrimary
                            )
                        }
                        if (activeProject != null) {
                            Text(
                                text = "${activeProject.techStack} • Commit: ${activeProject.gitCommitHash}",
                                style = MaterialTheme.typography.bodySmall,
                                color = CyberTextTertiary,
                                fontSize = 11.sp
                            )
                        }
                    }

                    // New Project & New File Actions
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(
                            onClick = { showNewProjectDialog = true },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CyberCyan,
                                contentColor = CyberBackground
                            ),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier
                                .height(32.dp)
                                .testTag("new_project_button")
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("NEW PROJECT", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        }

                        if (activeProject != null) {
                            OutlinedButton(
                                onClick = { showNewFileDialog = true },
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                modifier = Modifier
                                    .height(32.dp)
                                    .testTag("new_file_button")
                            ) {
                                Icon(Icons.Default.NoteAdd, contentDescription = null, modifier = Modifier.size(16.dp), tint = CyberCyan)
                            }
                        }
                    }
                }

                // Project Selector Tabs
                if (projects.size > 1) {
                    Spacer(Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(projects) { proj ->
                            val isSelected = activeProject?.id == proj.id
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (isSelected) CyberCyan.copy(alpha = 0.2f) else CyberSurfaceElevated,
                                border = BorderStroke(1.dp, if (isSelected) CyberCyan else CyberBorder),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable { onSelectProject(proj) }
                            ) {
                                Text(
                                    text = proj.name,
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) CyberCyan else CyberTextSecondary,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                }
            }
        }

        // Action Command Ribbon
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(CyberSurfaceElevated)
                .padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Autonomous Build & Fix Trigger
            Button(
                onClick = { onTriggerAutonomousBuild(activeProject?.name ?: "Android App") },
                colors = ButtonDefaults.buttonColors(containerColor = CyberBlue, contentColor = Color.White),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                modifier = Modifier
                    .height(30.dp)
                    .testTag("auto_build_button")
            ) {
                Icon(Icons.Default.AutoFixHigh, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(Modifier.width(4.dp))
                Text("AUTO BUILD & FIX", fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }

            // Run Tests
            OutlinedButton(
                onClick = {
                    onRunTests()
                    showTestDrawer = true
                },
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                modifier = Modifier
                    .height(30.dp)
                    .testTag("run_tests_button")
            ) {
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = CyberGreen, modifier = Modifier.size(14.dp))
                Spacer(Modifier.width(4.dp))
                Text("RUN TESTS", fontSize = 10.sp, color = CyberGreen)
            }

            // Output Drawer Toggle
            OutlinedButton(
                onClick = { showTestDrawer = !showTestDrawer },
                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                modifier = Modifier.height(30.dp)
            ) {
                Text("LOGS", fontSize = 10.sp, color = CyberTextSecondary)
            }
        }

        // File Explorer Tabs & Code Editor
        Column(modifier = Modifier.weight(1f).fillMaxWidth()) {
            // File tabs
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(CyberSurface)
                    .border(width = 1.dp, color = CyberBorder)
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(files) { file ->
                    val isSelected = selectedFile?.id == file.id
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = if (isSelected) TerminalBlack else CyberSurfaceVariant,
                        border = BorderStroke(1.dp, if (isSelected) CyberCyan else CyberBorder),
                        modifier = Modifier
                            .clip(RoundedCornerShape(6.dp))
                            .clickable { onSelectFile(file) }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = file.fileName,
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isSelected) CyberCyan else CyberTextSecondary,
                                fontSize = 11.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                            if (file.isModified) {
                                Spacer(Modifier.width(4.dp))
                                Box(modifier = Modifier.size(6.dp).clip(RoundedCornerShape(3.dp)).background(CyberAmber))
                            }
                        }
                    }
                }
            }

            // Code Editor
            CodeEditorView(
                file = selectedFile,
                onSaveContent = { newCode ->
                    if (selectedFile != null) {
                        onSaveFileContent(selectedFile.id, newCode)
                    }
                },
                onRunCode = { code, lang ->
                    onRunCode(code, lang)
                    consoleOutput = "--- Output: ${selectedFile?.fileName} ---\nExecution finished with Exit Code 0."
                    showTestDrawer = true
                },
                onDeleteFile = { file ->
                    onDeleteFile(file)
                },
                modifier = Modifier.weight(1f)
            )

            // Test Report / Output Drawer
            if (showTestDrawer) {
                Surface(
                    color = CyberSurface,
                    border = BorderStroke(1.dp, CyberBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(180.dp)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "🧪 Execution & Test Console",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = CyberTextPrimary,
                                fontSize = 13.sp
                            )
                            IconButton(
                                onClick = { showTestDrawer = false },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "Close", tint = CyberTextSecondary, modifier = Modifier.size(16.dp))
                            }
                        }

                        Spacer(Modifier.height(8.dp))

                        if (testReport != null) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(CyberGreen.copy(alpha = 0.15f))
                                    .padding(8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("PASSED: ${testReport.passedTests}/${testReport.totalTests}", color = CyberGreen, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                Text("DURATION: ${testReport.durationMs}ms", color = CyberTextSecondary, fontSize = 11.sp)
                            }
                            Spacer(Modifier.height(6.dp))
                            LazyColumn(modifier = Modifier.weight(1f)) {
                                items(testReport.testCases) { tc ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Text("✓ ${tc.name}", color = CyberTextPrimary, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                                        Text("${tc.durationMs}ms", color = CyberTextTertiary, fontSize = 10.sp)
                                    }
                                }
                            }
                        } else {
                            Text(
                                text = consoleOutput ?: "No test or build logs yet. Tap 'RUN TESTS' or 'AUTO BUILD'.",
                                style = MaterialTheme.typography.bodySmall,
                                fontFamily = FontFamily.Monospace,
                                color = CyberTextSecondary
                            )
                        }
                    }
                }
            }
        }
    }

    // New Project Requirement Dialog
    if (showNewProjectDialog) {
        var newProjName by remember { mutableStateOf("") }
        var newProjStack by remember { mutableStateOf("Kotlin / Jetpack Compose") }
        var newProjPrompt by remember { mutableStateOf("") }

        Dialog(onDismissRequest = { showNewProjectDialog = false }) {
            Surface(
                color = CyberSurface,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, CyberCyan),
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text("🚀 Create New Autonomous Project", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = CyberCyan)
                    Text("PAIOS AI Engineer will scaffold and build requirements.", style = MaterialTheme.typography.bodySmall, color = CyberTextSecondary)
                    Spacer(Modifier.height(14.dp))

                    OutlinedTextField(
                        value = newProjName,
                        onValueChange = { newProjName = it },
                        label = { Text("Project Name (e.g. WeatherApp)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(10.dp))

                    OutlinedTextField(
                        value = newProjPrompt,
                        onValueChange = { newProjPrompt = it },
                        label = { Text("Requirements / Description") },
                        placeholder = { Text("Describe features, login, DB, etc.") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(Modifier.height(16.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { showNewProjectDialog = false }, modifier = Modifier.weight(1f)) {
                            Text("CANCEL")
                        }
                        Button(
                            onClick = {
                                if (newProjName.isNotBlank()) {
                                    onTriggerAutonomousBuild(if (newProjPrompt.isNotBlank()) newProjPrompt else newProjName)
                                    showNewProjectDialog = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = CyberBackground),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("BUILD (بنائیں)", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }

    // New File Dialog
    if (showNewFileDialog && activeProject != null) {
        var newFileName by remember { mutableStateOf("") }
        var newFileLang by remember { mutableStateOf("kotlin") }

        Dialog(onDismissRequest = { showNewFileDialog = false }) {
            Surface(
                color = CyberSurface,
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, CyberCyan),
                modifier = Modifier.fillMaxWidth().padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text("📄 Create New File", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = CyberCyan)
                    Spacer(Modifier.height(12.dp))

                    OutlinedTextField(
                        value = newFileName,
                        onValueChange = { newFileName = it },
                        label = { Text("File Name (e.g. Repository.kt)") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(Modifier.height(16.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                        OutlinedButton(onClick = { showNewFileDialog = false }, modifier = Modifier.weight(1f)) {
                            Text("CANCEL")
                        }
                        Button(
                            onClick = {
                                if (newFileName.isNotBlank()) {
                                    onCreateNewFile(activeProject.id, newFileName, "// New File\n", newFileLang)
                                    showNewFileDialog = false
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = CyberCyan, contentColor = CyberBackground),
                            modifier = Modifier.weight(1f)
                        ) {
                            Text("CREATE")
                        }
                    }
                }
            }
        }
    }
}
