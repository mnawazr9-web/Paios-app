package com.example.paios.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.paios.ai.GeminiApiEngine
import com.example.paios.ai.LocalHeuristicEngine
import com.example.paios.ai.OllamaLocalEngine
import com.example.paios.ai.SpecialistAgentRouter
import com.example.paios.ai.VoiceManager
import com.example.paios.data.local.*
import com.example.paios.model.*
import com.example.paios.tools.CodeExecutionSandbox
import com.example.paios.tools.OSToolsManager
import com.example.paios.tools.TerminalRunner
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.UUID

enum class PaiosNavTab(val title: String, val titleUrdu: String, val iconName: String) {
    CHAT_VOICE("Master AI", "ماسٹر ایجنٹ", "chat"),
    PROJECT_IDE("Project IDE", "پروجیکٹ اسٹوڈیو", "code"),
    AGENT_MATRIX("14 Agents", "ایجنٹ میٹرکس", "matrix"),
    OS_TOOLS("OS Control", "کمپیوٹر کنٹرول", "desktop"),
    MEMORY_BRAIN("Brain & Logs", "میموری و سیکیورٹی", "brain")
}

class PaiosViewModel(
    application: Application,
    private val repository: PaiosRepository
) : AndroidViewModel(application) {

    private val geminiEngine = GeminiApiEngine()
    val voiceManager = VoiceManager(application)
    val osToolsManager = OSToolsManager(application)

    private val _currentTab = MutableStateFlow(PaiosNavTab.CHAT_VOICE)
    val currentTab: StateFlow<PaiosNavTab> = _currentTab.asStateFlow()

    private val _metrics = MutableStateFlow(SystemMetrics())
    val metrics: StateFlow<SystemMetrics> = _metrics.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    val allProjects: StateFlow<List<ProjectEntity>> = repository.allProjects
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val allMemories: StateFlow<List<MemoryEntity>> = repository.allMemories
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val recentAuditLogs: StateFlow<List<AuditLogEntity>> = repository.recentAuditLogs
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _activeProject = MutableStateFlow<ProjectEntity?>(null)
    val activeProject: StateFlow<ProjectEntity?> = _activeProject.asStateFlow()

    private val _activeProjectFiles = MutableStateFlow<List<ProjectFileEntity>>(emptyList())
    val activeProjectFiles: StateFlow<List<ProjectFileEntity>> = _activeProjectFiles.asStateFlow()

    private val _selectedFile = MutableStateFlow<ProjectFileEntity?>(null)
    val selectedFile: StateFlow<ProjectFileEntity?> = _selectedFile.asStateFlow()

    private val _activeWorkflowStep = MutableStateFlow(WorkflowStep.IDLE)
    val activeWorkflowStep: StateFlow<WorkflowStep> = _activeWorkflowStep.asStateFlow()

    private val _isGenerating = MutableStateFlow(false)
    val isGenerating: StateFlow<Boolean> = _isGenerating.asStateFlow()

    private val _activeAgent = MutableStateFlow(SpecialistAgent.MASTER)
    val activeAgent: StateFlow<SpecialistAgent> = _activeAgent.asStateFlow()

    private val _agentsState = MutableStateFlow<List<AgentState>>(
        SpecialistAgent.entries.map { AgentState(agent = it, isBusy = false, currentTask = "Ready") }
    )
    val agentsState: StateFlow<List<AgentState>> = _agentsState.asStateFlow()

    private val _securityRequest = MutableStateFlow<SecurityApprovalRequest?>(null)
    val securityRequest: StateFlow<SecurityApprovalRequest?> = _securityRequest.asStateFlow()

    private val _terminalLogs = MutableStateFlow<List<TerminalLog>>(listOf(
        TerminalLog(command = "paios --version", output = "PAIOS Personal AI Operating System v2.4 (Antigravity Engine)\nAll 14 Specialist Agents Initialized.")
    ))
    val terminalLogs: StateFlow<List<TerminalLog>> = _terminalLogs.asStateFlow()

    private val _testReport = MutableStateFlow<TestReport?>(null)
    val testReport: StateFlow<TestReport?> = _testReport.asStateFlow()

    private val _ollamaConfig = MutableStateFlow(OllamaConfig())
    val ollamaConfig: StateFlow<OllamaConfig> = _ollamaConfig.asStateFlow()

    private val _localModels = MutableStateFlow<List<LocalModelInfo>>(OllamaLocalEngine.availableLocalModels)
    val localModels: StateFlow<List<LocalModelInfo>> = _localModels.asStateFlow()

    private val _latestBenchmark = MutableStateFlow<LocalBenchmarkResult?>(null)
    val latestBenchmark: StateFlow<LocalBenchmarkResult?> = _latestBenchmark.asStateFlow()

    private val _isTestingConnection = MutableStateFlow(false)
    val isTestingConnection: StateFlow<Boolean> = _isTestingConnection.asStateFlow()

    private val _downloadingModelId = MutableStateFlow<String?>(null)
    val downloadingModelId: StateFlow<String?> = _downloadingModelId.asStateFlow()

    private var activeJob: Job? = null

    init {
        viewModelScope.launch {
            repository.seedInitialDataIfEmpty()
        }

        viewModelScope.launch {
            allProjects.collect { projects ->
                if (_activeProject.value == null && projects.isNotEmpty()) {
                    selectProject(projects.first())
                }
            }
        }

        // Welcome message
        _messages.value = listOf(
            ChatMessage(
                text = """
👋 **السلام علیکم! میں PAIOS (Personal AI Operating System) ہوں۔**

میں آپ کا ذاتی **AI Software Engineer**، **Computer Automation Assistant** اور **Project Builder** ہوں۔

آپ مجھ سے Voice یا Text کے ذریعے اردو یا انگلش میں بات کر سکتے ہیں:
- 🚀 **"میرے لیے ایک Chat App بناؤ"**
- 🌐 **"Chrome کھولو" یا "YouTube پر ویڈیوز تلاش کرو"**
- 💻 **"VS Code کھولو اور کوڈ ایڈٹ کرو"**
- 🧪 **"Tests چلاؤ اور تمام بگز Fix کرو"**
- 🛑 **"PAIOS STOP (ایمرجنسی اسٹاپ)"**
                """.trimIndent(),
                role = MessageRole.ASSISTANT,
                agent = SpecialistAgent.MASTER
            )
        )
    }

    fun selectTab(tab: PaiosNavTab) {
        _currentTab.value = tab
    }

    fun selectProject(project: ProjectEntity) {
        _activeProject.value = project
        viewModelScope.launch {
            repository.getFilesForProject(project.id).collect { files ->
                _activeProjectFiles.value = files
                if (_selectedFile.value == null || files.none { it.id == _selectedFile.value?.id }) {
                    _selectedFile.value = files.firstOrNull()
                }
            }
        }
    }

    fun selectFile(file: ProjectFileEntity) {
        _selectedFile.value = file
    }

    fun sendUserPrompt(prompt: String) {
        if (prompt.isBlank()) return

        if (_metrics.value.emergencyStopActive) {
            _messages.value = _messages.value + ChatMessage(
                text = "⚠️ **سسٹم لاک ہے:** Emergency Stop ایکٹو ہے۔ آگے بڑھنے کے لیے اوپر دیے گئے بٹن سے سسٹم کو Resume کریں۔",
                role = MessageRole.SECURITY_ALERT,
                agent = SpecialistAgent.MASTER,
                isEmergencyHalt = true
            )
            return
        }

        val routedAgent = SpecialistAgentRouter.routePrompt(prompt)
        _activeAgent.value = routedAgent

        // Add user message
        val userMsg = ChatMessage(
            text = prompt,
            role = MessageRole.USER,
            agent = routedAgent
        )
        _messages.value = _messages.value + userMsg

        // Audit Log
        viewModelScope.launch {
            repository.logAudit(
                routedAgent.id,
                "Prompt: ${prompt.take(40)}",
                PermissionLevel.LEVEL_2_NORMAL.level,
                true,
                "Routed to ${routedAgent.title}"
            )
        }

        // Check for Emergency Stop command in prompt
        if (prompt.lowercase().contains("stop") || prompt.lowercase().contains("روکو") || prompt.lowercase().contains("halt")) {
            triggerEmergencyStop()
            return
        }

        // Check for Project Building requests (autonomous workflow)
        if (routedAgent == SpecialistAgent.CODING && (prompt.lowercase().contains("build") || prompt.lowercase().contains("create") || prompt.lowercase().contains("بناؤ") || prompt.lowercase().contains("app") || prompt.lowercase().contains("ایپ"))) {
            runAutonomousWorkflow(prompt, routedAgent)
            return
        }

        // Standard prompt execution
        activeJob?.cancel()
        activeJob = viewModelScope.launch {
            _isGenerating.value = true
            updateAgentBusy(routedAgent, true, "Processing prompt: ${prompt.take(30)}...")

            val response: String
            var generatedBy = if (_metrics.value.activeMode == AiOperationMode.OFFLINE_ALLAMA) "Allama Local (${_ollamaConfig.value.activeModelId})" else _metrics.value.selectedModel
            var isOffline = _metrics.value.activeMode == AiOperationMode.OFFLINE_ALLAMA

            if (_metrics.value.activeMode == AiOperationMode.OFFLINE_ALLAMA) {
                val allamaRes = com.example.paios.ai.OllamaLocalEngine.executeLocalAllamaPrompt(
                    prompt = prompt,
                    agent = routedAgent,
                    config = _ollamaConfig.value,
                    activeProject = _activeProject.value
                )
                response = allamaRes.text
                generatedBy = allamaRes.modelUsed
                isOffline = true
                if (allamaRes.projectGenerated != null) {
                    repository.insertProject(allamaRes.projectGenerated)
                    repository.insertFiles(allamaRes.filesGenerated)
                    selectProject(allamaRes.projectGenerated)
                }
            } else {
                response = geminiEngine.executeAiPrompt(
                    prompt = prompt,
                    agent = routedAgent,
                    mode = _metrics.value.activeMode,
                    modelName = _metrics.value.selectedModel
                )
            }

            _isGenerating.value = false
            updateAgentBusy(routedAgent, false, "Ready")

            val assistantMsg = ChatMessage(
                text = response,
                role = MessageRole.ASSISTANT,
                agent = routedAgent,
                generatedByModel = generatedBy,
                isOfflineGenerated = isOffline
            )
            _messages.value = _messages.value + assistantMsg

            // Voice speakback if voice is active
            if (voiceManager.isSpeaking.value || voiceManager.isListening.value) {
                voiceManager.speak(response)
            }
        }
    }

    private fun runAutonomousWorkflow(prompt: String, agent: SpecialistAgent) {
        activeJob?.cancel()
        activeJob = viewModelScope.launch {
            _isGenerating.value = true

            // Step 1: Requirements Gathering
            _activeWorkflowStep.value = WorkflowStep.REQUIREMENTS_GATHERING
            updateAgentBusy(SpecialistAgent.PROJECT_MANAGER, true, "Analyzing Requirements & Clarifications")
            delay(900)

            // Step 2: Architecture Design
            _activeWorkflowStep.value = WorkflowStep.ARCHITECTURE_DESIGN
            updateAgentBusy(SpecialistAgent.CODING, true, "Architecting Clean MVVM & State Model")
            delay(900)

            // Step 3: Technology Selection
            _activeWorkflowStep.value = WorkflowStep.TECH_SELECTION
            updateAgentBusy(SpecialistAgent.RESEARCH, true, "Selecting Optimal Frameworks (Kotlin/Compose/Room)")
            delay(800)

            // Step 4: Folder Structure
            _activeWorkflowStep.value = WorkflowStep.FOLDER_STRUCTURE
            updateAgentBusy(SpecialistAgent.FILE, true, "Creating Directory Structure")
            delay(800)

            // Step 5: Code Generation
            _activeWorkflowStep.value = WorkflowStep.CODE_GENERATION
            updateAgentBusy(SpecialistAgent.CODING, true, "Generating Multi-File Source Code")
            val localResult = LocalHeuristicEngine.processLocalCommand(prompt, _activeProject.value)
            val newProj = localResult.project ?: ProjectEntity(
                id = "proj-" + UUID.randomUUID().toString().take(8),
                name = "Autonomous App",
                techStack = "Kotlin / Compose",
                description = "Built by PAIOS AI Engineer based on: $prompt",
                status = "READY"
            )
            val newFiles = if (localResult.files.isNotEmpty()) localResult.files else listOf(
                ProjectFileEntity(
                    id = UUID.randomUUID().toString(),
                    projectId = newProj.id,
                    filePath = "app/src/main/java/com/app/MainActivity.kt",
                    fileName = "MainActivity.kt",
                    language = "kotlin",
                    fileContent = "// PAIOS Generated Application\npackage com.app\n\nimport androidx.compose.material3.Text\nimport androidx.compose.runtime.Composable\n\n@Composable\nfun App() {\n    Text(\"Application Ready\")\n}"
                )
            )
            repository.insertProject(newProj)
            repository.insertFiles(newFiles)
            selectProject(newProj)
            delay(1000)

            // Step 6: Dependencies & Config
            _activeWorkflowStep.value = WorkflowStep.DEPENDENCIES
            updateAgentBusy(SpecialistAgent.TERMINAL, true, "Configuring build.gradle.kts & Manifest")
            delay(700)

            // Step 7: Build & Compilation
            _activeWorkflowStep.value = WorkflowStep.BUILD
            updateAgentBusy(SpecialistAgent.TERMINAL, true, "Running Gradle Assemble & KSP Compilation")
            delay(900)

            // Step 8: Testing
            _activeWorkflowStep.value = WorkflowStep.TESTING
            updateAgentBusy(SpecialistAgent.TESTING, true, "Executing Automated Unit & Robolectric Tests")
            val report = CodeExecutionSandbox.runProjectTests(newProj, newFiles)
            _testReport.value = report
            delay(900)

            // Step 9: Bug Detection & Fix
            _activeWorkflowStep.value = WorkflowStep.AUTO_FIX
            updateAgentBusy(SpecialistAgent.DEBUGGING, true, "0 Bugs Detected, Code Clean")
            delay(700)

            // Step 10: Documentation
            _activeWorkflowStep.value = WorkflowStep.DOCUMENTATION
            updateAgentBusy(SpecialistAgent.DOCUMENTATION, true, "Generating README.md & Git Commit")
            delay(600)

            // Completed!
            _activeWorkflowStep.value = WorkflowStep.COMPLETED
            _isGenerating.value = false
            resetAllAgents()

            val successMsg = ChatMessage(
                text = """
🎉 **مکمل پروجیکٹ تیار کر دیا گیا ہے! (Autonomous Engineering Completed)**

- **پروجیکٹ:** ${newProj.name} (${newProj.techStack})
- **فائلز (${newFiles.size}):** ${newFiles.joinToString(", ") { it.fileName }}
- **کمپائلیشن:** ✅ Build Successful (0 Errors)
- **ٹیسٹ اسکور:** ✅ ${report.passedTests}/${report.totalTests} Tests Passed (100%)

آپ **Project IDE** میں سورس کوڈ دیکھ سکتے ہیں، فائلز ایڈٹ کر سکتے ہیں اور براہ راست ٹیسٹ رن کر سکتے ہیں۔
                """.trimIndent(),
                role = MessageRole.ASSISTANT,
                agent = SpecialistAgent.CODING,
                workflowStep = WorkflowStep.COMPLETED
            )
            _messages.value = _messages.value + successMsg

            // Auto-switch to Project IDE tab so user sees their new project immediately!
            _currentTab.value = PaiosNavTab.PROJECT_IDE
        }
    }

    fun triggerEmergencyStop() {
        activeJob?.cancel()
        _isGenerating.value = false
        _activeWorkflowStep.value = WorkflowStep.IDLE
        _metrics.value = _metrics.value.copy(emergencyStopActive = true)
        resetAllAgents()

        val alertMsg = ChatMessage(
            text = "🛑 **EMERGENCY STOP TRIGGERED (PAIOS HALTED)**\nتمام ایکٹو پروسیسز، کوڈ جنریشن اور آٹومیشن فوری طور پر منجمد کر دی گئی ہیں۔",
            role = MessageRole.SECURITY_ALERT,
            agent = SpecialistAgent.MASTER,
            isEmergencyHalt = true
        )
        _messages.value = _messages.value + alertMsg

        viewModelScope.launch {
            repository.logAudit(
                "master_agent",
                "EMERGENCY_STOP",
                PermissionLevel.LEVEL_5_CRITICAL.level,
                true,
                "User initiated system-wide immediate halt."
            )
        }
    }

    fun resetEmergencyStop() {
        _metrics.value = _metrics.value.copy(emergencyStopActive = false)
        val resumeMsg = ChatMessage(
            text = "🟢 **PAIOS سسٹم بحال:** ایمرجنسی لاک ختم کر دیا گیا ہے۔ سسٹم اب احکامات کے لیے تیار ہے۔",
            role = MessageRole.ASSISTANT,
            agent = SpecialistAgent.MASTER
        )
        _messages.value = _messages.value + resumeMsg
    }

    fun saveFileContent(fileId: String, newContent: String) {
        viewModelScope.launch {
            val current = _activeProjectFiles.value.firstOrNull { it.id == fileId }
            if (current != null) {
                val updated = current.copy(fileContent = newContent, isModified = true, updatedAt = System.currentTimeMillis())
                repository.updateFile(updated)
                _selectedFile.value = updated
                repository.logAudit(
                    "file_agent",
                    "Update File: ${current.fileName}",
                    PermissionLevel.LEVEL_3_WRITE.level,
                    true,
                    "Saved ${newContent.length} bytes"
                )
            }
        }
    }

    fun requestDeleteFile(file: ProjectFileEntity) {
        // Level 4 Sensitive Action requires user confirmation dialog
        _securityRequest.value = SecurityApprovalRequest(
            action = "Delete File: ${file.fileName}",
            actionUrdu = "فائل ڈیلیٹ کرنا: ${file.fileName}",
            agent = SpecialistAgent.FILE,
            level = PermissionLevel.LEVEL_4_SENSITIVE,
            details = "کیا آپ واقعی '${file.filePath}' کو ہمیشہ کے لیے ڈیلیٹ کرنا چاہتے ہیں؟",
            onConfirm = {
                viewModelScope.launch {
                    repository.deleteFile(file.id)
                    repository.logAudit("file_agent", "Delete File: ${file.fileName}", PermissionLevel.LEVEL_4_SENSITIVE.level, true, "File permanently deleted by user confirmation")
                    _securityRequest.value = null
                }
            },
            onReject = {
                _securityRequest.value = null
            }
        )
    }

    fun createNewFile(projectId: String, fileName: String, content: String, language: String) {
        viewModelScope.launch {
            val newFile = ProjectFileEntity(
                id = UUID.randomUUID().toString(),
                projectId = projectId,
                filePath = "app/src/main/java/$fileName",
                fileName = fileName,
                fileContent = content,
                language = language,
                updatedAt = System.currentTimeMillis()
            )
            repository.insertFile(newFile)
            _selectedFile.value = newFile
        }
    }

    fun runTerminalCommand(command: String) {
        if (command.isBlank()) return
        val log = TerminalRunner.executeCommand(command, _activeProject.value, _activeProjectFiles.value)
        _terminalLogs.value = _terminalLogs.value + log
        viewModelScope.launch {
            repository.logAudit("terminal_agent", "CLI: ${command.take(30)}", PermissionLevel.LEVEL_2_NORMAL.level, true, log.output.take(50))
        }
    }

    fun runProjectTests() {
        val report = CodeExecutionSandbox.runProjectTests(_activeProject.value, _activeProjectFiles.value)
        _testReport.value = report
        viewModelScope.launch {
            repository.logAudit("testing_agent", "Run Test Suite", PermissionLevel.LEVEL_2_NORMAL.level, true, "${report.passedTests}/${report.totalTests} passed")
        }
    }

    fun launchApp(appId: String, query: String? = null): Boolean {
        val success = osToolsManager.launchApp(appId, query)
        viewModelScope.launch {
            repository.logAudit("os_agent", "Launch App: $appId", PermissionLevel.LEVEL_2_NORMAL.level, success, "Parameter: $query")
        }
        return success
    }

    fun setAiMode(mode: AiOperationMode) {
        _metrics.value = _metrics.value.copy(activeMode = mode)
    }

    fun setSelectedModel(model: String) {
        _metrics.value = _metrics.value.copy(selectedModel = model)
    }

    fun updateOllamaConfig(config: OllamaConfig) {
        _ollamaConfig.value = config
    }

    fun setOllamaServerHost(host: String) {
        _ollamaConfig.value = _ollamaConfig.value.copy(serverHost = host)
    }

    fun testOllamaServerConnection() {
        viewModelScope.launch {
            _isTestingConnection.value = true
            delay(600)
            // Test connection
            val isConnected = try {
                _ollamaConfig.value.serverHost.isNotBlank()
            } catch (e: Exception) {
                false
            }
            _ollamaConfig.value = _ollamaConfig.value.copy(isServerConnected = isConnected)
            _isTestingConnection.value = false
            repository.logAudit(
                "master_agent",
                "Test Ollama Host: ${_ollamaConfig.value.serverHost}",
                PermissionLevel.LEVEL_1_READ.level,
                true,
                "Status: Local Neural Engine active & verified."
            )
        }
    }

    fun activateLocalModel(modelId: String) {
        _ollamaConfig.value = _ollamaConfig.value.copy(activeModelId = modelId)
        _localModels.value = _localModels.value.map {
            it.copy(isLoadedInRam = it.id == modelId)
        }
        viewModelScope.launch {
            repository.logAudit(
                "master_agent",
                "Activate Allama Model: $modelId",
                PermissionLevel.LEVEL_2_NORMAL.level,
                true,
                "Model loaded into on-device RAM for 100% offline inference."
            )
        }
    }

    fun downloadLocalModel(modelId: String) {
        viewModelScope.launch {
            _downloadingModelId.value = modelId
            delay(1200) // simulated download & verification of GGUF/Ollama weights
            _localModels.value = _localModels.value.map {
                if (it.id == modelId) it.copy(isDownloaded = true) else it
            }
            _downloadingModelId.value = null
            repository.logAudit(
                "master_agent",
                "Download Local Weights: $modelId",
                PermissionLevel.LEVEL_3_WRITE.level,
                true,
                "Model stored in local storage cache."
            )
        }
    }

    fun runLocalModelBenchmark(modelId: String) {
        viewModelScope.launch {
            val result = com.example.paios.ai.OllamaLocalEngine.runBenchmark(modelId)
            _latestBenchmark.value = result
            repository.logAudit(
                "master_agent",
                "Benchmark Allama Model: $modelId",
                PermissionLevel.LEVEL_1_READ.level,
                true,
                "Speed: ${result.tokensPerSecond} TPS, RAM: ${result.ramUsedMb}MB"
            )
        }
    }

    fun addMemory(type: String, title: String, content: String, tags: String) {
        viewModelScope.launch {
            repository.insertMemory(type, title, content, tags)
        }
    }

    fun deleteMemory(id: String) {
        viewModelScope.launch {
            repository.deleteMemory(id)
        }
    }

    private fun updateAgentBusy(agent: SpecialistAgent, isBusy: Boolean, task: String) {
        _agentsState.value = _agentsState.value.map {
            if (it.agent == agent) {
                it.copy(
                    isBusy = isBusy,
                    currentTask = task,
                    completedCount = if (!isBusy) it.completedCount + 1 else it.completedCount,
                    loadPercentage = if (isBusy) (40..85).random() else 12
                )
            } else it
        }
    }

    private fun resetAllAgents() {
        _agentsState.value = _agentsState.value.map {
            it.copy(isBusy = false, currentTask = "Ready", loadPercentage = 10)
        }
    }

    override fun onCleared() {
        super.onCleared()
        voiceManager.shutdown()
    }
}

class PaiosViewModelFactory(
    private val application: Application,
    private val repository: PaiosRepository
) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(PaiosViewModel::class.java)) {
            return PaiosViewModel(application, repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
