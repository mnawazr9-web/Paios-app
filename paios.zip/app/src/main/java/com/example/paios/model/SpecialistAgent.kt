package com.example.paios.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.*

enum class SpecialistAgent(
    val id: String,
    val title: String,
    val titleUrdu: String,
    val roleDescription: String,
    val roleDescriptionUrdu: String,
    val badgeColor: Color,
    val systemPromptHint: String
) {
    MASTER(
        id = "master_agent",
        title = "Master OS Agent",
        titleUrdu = "ماسٹر او ایس ایجنٹ",
        roleDescription = "Central orchestrator coordinating specialist agents and managing tasks.",
        roleDescriptionUrdu = "تمام خصوصی ایجنٹس کی نگرانی اور ٹاسک مینیجمنٹ",
        badgeColor = CyberCyan,
        systemPromptHint = "You are the Master Agent of PAIOS (Personal AI Operating System). Direct requests to specialist agents or handle orchestration."
    ),
    CODING(
        id = "coding_agent",
        title = "Coding Agent",
        titleUrdu = "کوڈنگ ایجنٹ",
        roleDescription = "Designs multi-file architecture, writes clean source code across Kotlin, Python, JS, Flutter, React, etc.",
        roleDescriptionUrdu = "مکمل سورس کوڈ اور پروجیکٹ اسٹرکچر تیار کرنا",
        badgeColor = CyberElectric,
        systemPromptHint = "You are the AI Software Engineer of PAIOS. Write production-ready code, complete file structures, and handle full projects."
    ),
    DEBUGGING(
        id = "debugging_agent",
        title = "Debugging Agent",
        titleUrdu = "ڈیبگنگ ایجنٹ",
        roleDescription = "Analyzes build logs, stack traces, pinpoints root causes, and generates precise code fixes.",
        roleDescriptionUrdu = "غلطیوں کی نشاندہی، لاگ تجزیہ اور خودکار فکسنگ",
        badgeColor = CyberCrimson,
        systemPromptHint = "You are the Debugging Specialist of PAIOS. Diagnose errors from execution logs and provide precise patch fixes."
    ),
    TESTING(
        id = "testing_agent",
        title = "Testing Agent",
        titleUrdu = "ٹیسٹنگ ایجنٹ",
        roleDescription = "Generates unit tests, integration tests, runs validation suites, and outputs structured pass/fail reports.",
        roleDescriptionUrdu = "یونٹ اور انٹیگریشن ٹیسٹس بنانا اور چلانا",
        badgeColor = CyberGreen,
        systemPromptHint = "You are the QA & Testing Specialist of PAIOS. Write thorough unit/integration tests and verify builds."
    ),
    UI_UX(
        id = "ui_ux_agent",
        title = "UI/UX Agent",
        titleUrdu = "یو آئی / یو ایکس ایجنٹ",
        roleDescription = "Designs responsive interfaces, aesthetic themes, layout mockups, and accessibility standards.",
        roleDescriptionUrdu = "جدید ڈیزائن، لے آؤٹس اور انٹرفیس اسٹائلنگ",
        badgeColor = CyberPink,
        systemPromptHint = "You are the UI/UX Design Specialist of PAIOS. Architect modern, intuitive, high-contrast layouts and responsive designs."
    ),
    PROJECT_MANAGER(
        id = "pm_agent",
        title = "Project Manager Agent",
        titleUrdu = "پروجیکٹ مینیجر ایجنٹ",
        roleDescription = "Collects requirements via interactive Q&A, plans milestones, technology stacks, and tracks workflow state.",
        roleDescriptionUrdu = "صارف سے سوالات، ضروریات اکٹھی کرنا اور روڈ میپ بنانا",
        badgeColor = CyberAmber,
        systemPromptHint = "You are the Project Manager of PAIOS. Interview the user for requirements, clarify ambiguities, and plan roadmaps."
    ),
    BROWSER(
        id = "browser_agent",
        title = "Browser Agent",
        titleUrdu = "براؤزر ایجنٹ",
        roleDescription = "Executes web searches, YouTube video searches, opens URLs, and extracts web content.",
        roleDescriptionUrdu = "ویب سرچ، یوٹیوب ویڈیوز اور براؤزنگ آٹومیشن",
        badgeColor = CyberBlue,
        systemPromptHint = "You are the Browser Automation Agent of PAIOS. Search the web, find technical documentation, and automate URLs."
    ),
    FILE(
        id = "file_agent",
        title = "File System Agent",
        titleUrdu = "فائل سسٹم ایجنٹ",
        roleDescription = "Manages files & folders: create, read, write, edit, rename, move, and secure delete.",
        roleDescriptionUrdu = "فائلز بنانا، پڑھنا، ایڈٹ کرنا اور منتقل کرنا",
        badgeColor = CyberEmerald,
        systemPromptHint = "You are the File System Agent of PAIOS. Manage storage safely with Level 4 permission checks on deletions."
    ),
    TERMINAL(
        id = "terminal_agent",
        title = "Terminal & CLI Agent",
        titleUrdu = "ٹرمینل ایجنٹ",
        roleDescription = "Executes shell commands, builds, package managers, and Git version control operations.",
        roleDescriptionUrdu = "کمانڈ لائن، گٹ اور پیکج مینیجر کنٹرول",
        badgeColor = CyberPurple,
        systemPromptHint = "You are the Terminal Agent of PAIOS. Execute system commands, builds, and version control workflows."
    ),
    OS_AUTOMATION(
        id = "os_agent",
        title = "OS Automation Agent",
        titleUrdu = "او ایس آٹومیشن ایجنٹ",
        roleDescription = "Controls computer apps (Chrome, VS Code, Terminal), processes, windows, clipboard, and notifications.",
        roleDescriptionUrdu = "کمپیوٹر ایپلی کیشنز، پروسیسز اور کلپ بورڈ کنٹرول",
        badgeColor = CyberCyan,
        systemPromptHint = "You are the OS Automation Agent of PAIOS. Launch applications and control system operations."
    ),
    RESEARCH(
        id = "research_agent",
        title = "Research Agent",
        titleUrdu = "ریسرچ ایجنٹ",
        roleDescription = "Evaluates frameworks, APIs, libraries, benchmarks, and provides architectural comparisons.",
        roleDescriptionUrdu = "ٹیکنالوجی کا موازنہ اور ریسرچ ڈیٹا",
        badgeColor = CyberOrange,
        systemPromptHint = "You are the Research Specialist of PAIOS. Provide deep technical analysis, comparisons, and best practices."
    ),
    DOCUMENTATION(
        id = "docs_agent",
        title = "Documentation Agent",
        titleUrdu = "ڈاکیو مینٹیشن ایجنٹ",
        roleDescription = "Generates comprehensive READMEs, API guides, architecture diagrams, and release changelogs.",
        roleDescriptionUrdu = "پروجیکٹ کی دستاویزات اور گائیڈز تیار کرنا",
        badgeColor = CyberEmerald,
        systemPromptHint = "You are the Documentation Specialist of PAIOS. Write clear, structured Markdown documentation."
    ),
    VOICE(
        id = "voice_agent",
        title = "Voice Agent",
        titleUrdu = "وائس ایجنٹ",
        roleDescription = "Processes speech recognition in Urdu and English, detects intent, and generates spoken voice responses.",
        roleDescriptionUrdu = "آواز سے ہدایات سننا اور بول کر جواب دینا",
        badgeColor = CyberGreen,
        systemPromptHint = "You are the Voice Processing Specialist of PAIOS. Handle spoken speech interactions fluently in Urdu and English."
    ),
    VISION(
        id = "vision_agent",
        title = "Vision Agent",
        titleUrdu = "ویژن ایجنٹ",
        roleDescription = "Analyzes UI screenshots, inspects visual components, recognizes buttons, and spots visual UI bugs.",
        roleDescriptionUrdu = "اسکرین اور تصاویر کا بصری تجزیہ",
        badgeColor = CyberPurple,
        systemPromptHint = "You are the Vision Specialist of PAIOS. Inspect screenshots, identify UI layout bugs, and analyze visuals."
    ),
    MEMORY(
        id = "memory_agent",
        title = "Memory & Learning Agent",
        titleUrdu = "میموری اور لرننگ ایجنٹ",
        roleDescription = "Manages short-term conversation context, long-term user preferences, project histories, and skill learning.",
        roleDescriptionUrdu = "صارف کی ترجیحات اور پروجیکٹ ہسٹری محفوظ رکھنا",
        badgeColor = CyberAmber,
        systemPromptHint = "You are the Memory & Learning Agent of PAIOS. Retrieve past project contexts and user preferences accurately."
    );

    companion object {
        fun fromId(id: String): SpecialistAgent {
            return entries.firstOrNull { it.id == id } ?: MASTER
        }
    }
}
