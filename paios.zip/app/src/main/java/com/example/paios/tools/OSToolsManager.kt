package com.example.paios.tools

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.example.paios.model.OSApplication

class OSToolsManager(private val context: Context) {

    val systemApps = listOf(
        OSApplication("app-chrome", "Google Chrome", "گوگل کروم", "com.android.chrome", "Browser", false, "chrome"),
        OSApplication("app-youtube", "YouTube", "یوٹیوب", "com.google.android.youtube", "Media", false, "youtube"),
        OSApplication("app-vscode", "VS Code Studio", "وی ایس کوڈ اسٹوڈیو", "com.microsoft.vscode", "Development", true, "code"),
        OSApplication("app-terminal", "PAIOS Terminal CLI", "ٹرمینل", "com.paios.terminal", "System", true, "terminal"),
        OSApplication("app-studio", "Android Studio IDE", "اینڈرائیڈ اسٹوڈیو", "com.google.androidstudio", "Development", false, "android"),
        OSApplication("app-calc", "Calculator", "کیلکولیٹر", "com.google.android.calculator", "Utility", false, "calc"),
        OSApplication("app-files", "File Explorer", "فائل مینیجر", "com.android.documentsui", "Storage", false, "folder"),
        OSApplication("app-docker", "Docker Engine", "ڈاکر انجن", "com.docker.engine", "DevOps", false, "docker"),
        OSApplication("app-settings", "System Settings", "سسٹم سیٹنگز", "com.android.settings", "System", false, "settings")
    )

    fun launchApp(appId: String, parameter: String? = null): Boolean {
        return try {
            when (appId) {
                "app-chrome" -> {
                    val url = parameter ?: "https://www.google.com"
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(intent)
                    true
                }
                "app-youtube" -> {
                    val url = if (!parameter.isNullOrBlank()) {
                        "https://www.youtube.com/results?search_query=${Uri.encode(parameter)}"
                    } else {
                        "https://www.youtube.com"
                    }
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(intent)
                    true
                }
                "app-settings" -> {
                    val intent = Intent(android.provider.Settings.ACTION_SETTINGS).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK
                    }
                    context.startActivity(intent)
                    true
                }
                else -> {
                    // Simulated developer tools (VS Code, Terminal, Android Studio, Docker)
                    true
                }
            }
        } catch (e: Exception) {
            false
        }
    }
}
