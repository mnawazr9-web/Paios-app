package com.example.paios.model

enum class WorkflowStep(
    val stepNumber: Int,
    val title: String,
    val titleUrdu: String,
    val agent: SpecialistAgent,
    val description: String
) {
    IDLE(
        stepNumber = 0,
        title = "Idle / Ready",
        titleUrdu = "تیار",
        agent = SpecialistAgent.MASTER,
        description = "PAIOS is ready for user commands."
    ),
    REQUIREMENTS_GATHERING(
        stepNumber = 1,
        title = "Requirements Analysis",
        titleUrdu = "ضروریات کا جائزہ و سوالات",
        agent = SpecialistAgent.PROJECT_MANAGER,
        description = "Analyzing user intent and formulating clarifying questions."
    ),
    ARCHITECTURE_DESIGN(
        stepNumber = 2,
        title = "Architecture Design",
        titleUrdu = "پروجیکٹ آرکیٹیکچر ڈیزائن",
        agent = SpecialistAgent.CODING,
        description = "Designing modules, data models, state flows, and tech stack."
    ),
    TECH_SELECTION(
        stepNumber = 3,
        title = "Technology Stack",
        titleUrdu = "ٹیکنالوجی کا انتخاب",
        agent = SpecialistAgent.RESEARCH,
        description = "Selecting optimal libraries, frameworks, and versions."
    ),
    FOLDER_STRUCTURE(
        stepNumber = 4,
        title = "Folder & File Tree",
        titleUrdu = "فائل اور فولڈر اسٹرکچر",
        agent = SpecialistAgent.FILE,
        description = "Generating modular directory structure and boilerplate paths."
    ),
    CODE_GENERATION(
        stepNumber = 5,
        title = "Source Code Generation",
        titleUrdu = "مکمل سورس کوڈ کی تخلیق",
        agent = SpecialistAgent.CODING,
        description = "Writing production-grade source code for all required files."
    ),
    DEPENDENCIES(
        stepNumber = 6,
        title = "Dependencies & Config",
        titleUrdu = "پیکجز اور کنفیگریشن",
        agent = SpecialistAgent.TERMINAL,
        description = "Configuring build scripts, package managers, and environment variables."
    ),
    BUILD(
        stepNumber = 7,
        title = "Build & Compilation",
        titleUrdu = "پروجیکٹ بلڈ اور کمپائلیشن",
        agent = SpecialistAgent.TERMINAL,
        description = "Running build compilation and syntax verification."
    ),
    TESTING(
        stepNumber = 8,
        title = "Automated Test Suite",
        titleUrdu = "یونٹ اور انٹیگریشن ٹیسٹس",
        agent = SpecialistAgent.TESTING,
        description = "Running unit tests, edge-case assertions, and UI layout checks."
    ),
    BUG_DETECTION(
        stepNumber = 9,
        title = "Error & Bug Analysis",
        titleUrdu = "غلطیوں اور بگز کی تشخیص",
        agent = SpecialistAgent.DEBUGGING,
        description = "Inspecting failures, stack traces, and determining root causes."
    ),
    AUTO_FIX(
        stepNumber = 10,
        title = "Autonomous Bug Fixing",
        titleUrdu = "خودکار پیچ اور ایرر فکسنگ",
        agent = SpecialistAgent.DEBUGGING,
        description = "Applying surgical code fixes and re-verifying test passes."
    ),
    DOCUMENTATION(
        stepNumber = 11,
        title = "Documentation & Changelog",
        titleUrdu = "دستاویزات اور گٹ ہسٹری",
        agent = SpecialistAgent.DOCUMENTATION,
        description = "Generating README.md, API specs, and Git commit history."
    ),
    COMPLETED(
        stepNumber = 12,
        title = "Project Ready & Deployed",
        titleUrdu = "پروجیکٹ مکمل اور فعال",
        agent = SpecialistAgent.MASTER,
        description = "Full autonomous workflow completed successfully."
    );

    val progressFraction: Float
        get() = if (stepNumber == 0) 0f else stepNumber / 12f
}
