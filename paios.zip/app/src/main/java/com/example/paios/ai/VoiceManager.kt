package com.example.paios.ai

import android.content.Context
import android.speech.tts.TextToSpeech
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class VoiceManager(private val context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    private var isTtsReady = false

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _audioWaveformEnergy = MutableStateFlow(listOf(0.2f, 0.4f, 0.8f, 0.5f, 0.3f, 0.9f, 0.4f, 0.2f))
    val audioWaveformEnergy: StateFlow<List<Float>> = _audioWaveformEnergy.asStateFlow()

    init {
        tts = TextToSpeech(context.applicationContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = tts?.setLanguage(Locale.US)
            if (result != TextToSpeech.LANG_MISSING_DATA && result != TextToSpeech.LANG_NOT_SUPPORTED) {
                isTtsReady = true
            }
        }
    }

    fun speak(text: String) {
        if (!isTtsReady || tts == null) return

        // Clean markdown syntax for spoken speech
        val cleanedText = text
            .replace(Regex("[*#`_~-]"), "")
            .replace(Regex("\\[.*?\\]\\(.*?\\)"), "")
            .take(300)

        _isSpeaking.value = true
        tts?.speak(cleanedText, TextToSpeech.QUEUE_FLUSH, null, "PAIOS_TTS_UTTERANCE")
    }

    fun stopSpeaking() {
        tts?.stop()
        _isSpeaking.value = false
    }

    fun setListening(listening: Boolean) {
        _isListening.value = listening
    }

    fun updateWaveform(energies: List<Float>) {
        _audioWaveformEnergy.value = energies
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
    }
}
