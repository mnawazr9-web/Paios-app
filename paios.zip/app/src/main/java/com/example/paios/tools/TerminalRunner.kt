package com.example.paios.tools

import com.example.paios.data.local.ProjectEntity
import com.example.paios.data.local.ProjectFileEntity
import com.example.paios.model.TerminalLog
import com.example.paios.model.TestReport
import com.example.paios.model.TestCaseResult

object TerminalRunner {

    fun executeCommand(
        cmd: String,
        activeProject: ProjectEntity?,
        files: List<ProjectFileEntity>
    ): TerminalLog {
        val trimmed = cmd.trim()
        val parts = trimmed.split(" ").filter { it.isNotBlank() }
        val command = parts.firstOrNull() ?: ""

        return when (command) {
            "help" -> TerminalLog(
                command = cmd,
                output = """
PAIOS Autonomous CLI v2.4 (Antigravity Core)
Available commands:
  ls, dir               - List project directory files
  cat <file>            - View file content
  git status            - Show repository status and commits
  git log               - Show recent commit history
  git commit -m <msg>   - Commit active workspace changes
  gradle build          - Compile and assemble Android project
  gradle test           - Run unit tests & Roborazzi screenshot tests
  npm run build         - Build frontend web bundle
  python <file>         - Execute Python script
  ps, top               - Show running AI OS agent processes
  clear                 - Clear terminal buffer
  whoami                - Show current PAIOS user & security level
                """.trimIndent()
            )

            "whoami" -> TerminalLog(
                command = cmd,
                output = "paios-root@paios-os [Security Clearance: Level 5 Administrator, Active Engine: Gemini 3.5 Flash]"
            )

            "ls", "dir" -> {
                if (files.isEmpty()) {
                    TerminalLog(command = cmd, output = "(empty workspace - no active project files)")
                } else {
                    val listing = files.joinToString("\n") { file ->
                        val size = file.fileContent.length
                        val badge = when (file.language) {
                            "kotlin" -> "📦 [KT]"
                            "python" -> "🐍 [PY]"
                            "javascript", "typescript" -> "⚡ [JS]"
                            "markdown" -> "📝 [MD]"
                            else -> "📄 [FILE]"
                        }
                        "$badge ${file.filePath.padEnd(45)} ${size}B  (updated ${file.updatedAt})"
                    }
                    TerminalLog(command = cmd, output = listing)
                }
            }

            "cat" -> {
                val targetName = parts.getOrNull(1)
                if (targetName == null) {
                    TerminalLog(command = cmd, output = "Error: Usage 'cat <filename>'", isError = true)
                } else {
                    val file = files.firstOrNull { it.fileName.equals(targetName, ignoreCase = true) || it.filePath.endsWith(targetName) }
                    if (file != null) {
                        TerminalLog(command = cmd, output = file.fileContent)
                    } else {
                        TerminalLog(command = cmd, output = "Error: File '$targetName' not found in project workspace.", isError = true)
                    }
                }
            }

            "git" -> {
                val sub = parts.getOrNull(1)
                when (sub) {
                    "status" -> TerminalLog(
                        command = cmd,
                        output = """
On branch main
Your branch is up to date with 'origin/main'.

Workspace: ${activeProject?.name ?: "No project selected"}
Commit: ${activeProject?.gitCommitHash ?: "init-001"}
Tracked files (${files.size}):
${files.joinToString("\n") { "  modified: " + it.filePath }}

nothing to commit, working tree clean
                        """.trimIndent()
                    )
                    "log" -> TerminalLog(
                        command = cmd,
                        output = """
commit a8f12c980b12 (HEAD -> main)
Author: PAIOS Autonomous Engineer <ai@paios.os>
Date:   Sat Aug 22 2026

    feat: Autonomous architecture generation & Room DB integration

commit 401bb2e9710a
Author: PAIOS Master Agent <master@paios.os>
Date:   Sat Aug 22 2026

    init: Scaffolded project template and test suites
                        """.trimIndent()
                    )
                    "commit" -> TerminalLog(
                        command = cmd,
                        output = "[main 7f20a1c] ${cmd.substringAfter("-m", "chore: automated agent sync")}\n ${files.size} files changed, 240 insertions(+)"
                    )
                    else -> TerminalLog(command = cmd, output = "git: '$sub' is executed. Branch: main (clean)")
                }
            }

            "gradle", "./gradlew" -> {
                val task = parts.getOrNull(1) ?: "build"
                if (task.contains("test")) {
                    TerminalLog(
                        command = cmd,
                        output = """
> Task :app:compileDebugKotlin UP-TO-DATE
> Task :app:processDebugResources UP-TO-DATE
> Task :app:testDebugUnitTest

com.example.ChatUnitTest > testMessageValidation PASSED
com.example.ChatUnitTest > testEncryptionKeyGeneration PASSED
com.example.ExampleRobolectricTest > testAutonomousWorkflow PASSED

BUILD SUCCESSFUL in 1.42s
3 actionable tasks: 3 executed
                        """.trimIndent()
                    )
                } else {
                    TerminalLog(
                        command = cmd,
                        output = """
> Task :app:kspDebugKotlin
> Task :app:compileDebugKotlin
> Task :app:mergeDebugNativeLibs
> Task :app:packageDebug
> Task :app:assembleDebug

BUILD SUCCESSFUL in 2.18s
42 actionable tasks: 6 executed, 36 up-to-date
Output: app-debug.apk (14.2 MB)
                        """.trimIndent()
                    )
                }
            }

            "ps", "top" -> TerminalLog(
                command = cmd,
                output = """
PID   USER      AGENT            %CPU  %MEM   STATE   COMMAND
101   paios     Master Agent      4.2   1.2   RUN     paios-orchestrator
102   paios     Coding Agent      8.6   3.4   RUN     paios-code-gen
103   paios     Testing Agent     1.1   0.8   IDLE    paios-test-runner
104   paios     Debugging Agent   0.2   0.4   IDLE    paios-bug-analyzer
105   paios     Terminal Agent    2.0   1.0   RUN     paios-cli-sandbox
                """.trimIndent()
            )

            "clear" -> TerminalLog(command = cmd, output = "")

            else -> TerminalLog(
                command = cmd,
                output = "$command: command executed successfully (exit code 0)"
            )
        }
    }
}

object CodeExecutionSandbox {

    fun runProjectTests(project: ProjectEntity?, files: List<ProjectFileEntity>): TestReport {
        val testFile = files.firstOrNull { it.fileName.contains("Test", ignoreCase = true) }
        val testCases = if (testFile != null) {
            listOf(
                TestCaseResult("testMessageValidation", true, 42),
                TestCaseResult("testEncryptionKeyGeneration", true, 68),
                TestCaseResult("testLocalDatabasePersistence", true, 115),
                TestCaseResult("testAgentWorkflowIntegrity", true, 54)
            )
        } else {
            listOf(
                TestCaseResult("testProjectCompilation", true, 80),
                TestCaseResult("testModuleResolution", true, 62),
                TestCaseResult("testSyntaxValidation", true, 45)
            )
        }

        return TestReport(
            totalTests = testCases.size,
            passedTests = testCases.count { it.passed },
            failedTests = testCases.count { !it.passed },
            testCases = testCases,
            durationMs = testCases.sumOf { it.durationMs },
            summary = "All unit tests and assertion suites passed with 100% success rate."
        )
    }

    fun executeActiveCode(code: String, language: String): String {
        return when (language.lowercase()) {
            "kotlin" -> """
--- Kotlin JVM Simulation Output ---
[System.out] Initializing Jetpack Compose runtime...
[System.out] Room SQLite Database instance created.
[System.out] UI rendered successfully (0 frame drops).
Execution completed in 84ms.
            """.trimIndent()

            "python" -> """
--- Python 3.12 Simulation Output ---
>>> import asyncio, sys
>>> print(f"PAIOS Autonomous Runtime running on {sys.platform}")
PAIOS Autonomous Runtime running on linux
[OK] Script executed with exit code 0 (24ms).
            """.trimIndent()

            "javascript", "typescript" -> """
--- Node.js v22 Simulation Output ---
> paios-app@1.0.0 dev
> Ready in 210ms
✓ Compiled /src/App.tsx in 120ms
✓ Local: http://localhost:3000
            """.trimIndent()

            else -> """
--- Executable Script Output ---
Output stream captured:
Execution finished successfully with Exit Code 0.
            """.trimIndent()
        }
    }
}
