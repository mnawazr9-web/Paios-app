package com.example.paios.ai

import com.example.BuildConfig
import com.example.paios.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class GeminiApiEngine {

    private val client = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun executeAiPrompt(
        prompt: String,
        agent: SpecialistAgent,
        mode: AiOperationMode,
        modelName: String = "gemini-3.5-flash",
        systemInstruction: String = ""
    ): String = withContext(Dispatchers.IO) {
        // If offline mode is chosen, immediately use Allama Local engine
        if (mode == AiOperationMode.OFFLINE_ALLAMA) {
            val localRes = OllamaLocalEngine.executeLocalAllamaPrompt(
                prompt = prompt,
                agent = agent,
                config = OllamaConfig(activeModelId = modelName)
            )
            return@withContext localRes.text
        }

        val apiKey = try {
            BuildConfig.GEMINI_API_KEY
        } catch (e: Throwable) {
            ""
        }

        if (apiKey.isBlank() || apiKey == "MY_GEMINI_API_KEY") {
            // No valid API key configured in secrets, fallback seamlessly to Allama Local engine
            val localRes = OllamaLocalEngine.executeLocalAllamaPrompt(
                prompt = prompt,
                agent = agent,
                config = OllamaConfig(activeModelId = "llama3.2:3b")
            )
            return@withContext localRes.text
        }

        try {
            val endpoint = "https://generativelanguage.googleapis.com/v1beta/models/$modelName:generateContent?key=$apiKey"

            val effectiveSystemPrompt = if (systemInstruction.isNotBlank()) {
                systemInstruction
            } else {
                "${agent.systemPromptHint} You are part of PAIOS (Personal AI Operating System). Answer clearly, intelligently, and support both English and Urdu requests."
            }

            val requestJson = JSONObject().apply {
                val contentsArray = JSONArray().apply {
                    val contentObj = JSONObject().apply {
                        val partsArray = JSONArray().apply {
                            put(JSONObject().apply { put("text", prompt) })
                        }
                        put("parts", partsArray)
                    }
                    put(contentObj)
                }
                put("contents", contentsArray)

                val systemObj = JSONObject().apply {
                    val partsArray = JSONArray().apply {
                        put(JSONObject().apply { put("text", effectiveSystemPrompt) })
                    }
                    put("parts", partsArray)
                }
                put("systemInstruction", systemObj)

                val genConfig = JSONObject().apply {
                    put("temperature", 0.7)
                    put("topP", 0.95)
                }
                put("generationConfig", genConfig)
            }

            val requestBody = requestJson.toString().toRequestBody(jsonMediaType)
            val request = Request.Builder()
                .url(endpoint)
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string()

            if (response.isSuccessful && !responseBody.isNullOrBlank()) {
                val jsonResponse = JSONObject(responseBody)
                val candidates = jsonResponse.optJSONArray("candidates")
                if (candidates != null && candidates.length() > 0) {
                    val candidate = candidates.getJSONObject(0)
                    val content = candidate.optJSONObject("content")
                    val parts = content?.optJSONArray("parts")
                    if (parts != null && parts.length() > 0) {
                        return@withContext parts.getJSONObject(0).optString("text", "No response generated.")
                    }
                }
            }

            // Fallback on API non-200
            LocalHeuristicEngine.processLocalCommand(prompt, null).textResponse
        } catch (e: Exception) {
            // Fallback gracefully to offline heuristic engine on network/timeout error
            LocalHeuristicEngine.processLocalCommand(prompt, null).textResponse
        }
    }
}
