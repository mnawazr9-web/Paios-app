package com.example.paios.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.*

enum class PermissionLevel(
    val level: Int,
    val title: String,
    val titleUrdu: String,
    val description: String,
    val descriptionUrdu: String,
    val color: Color,
    val requiresUserApproval: Boolean,
    val requiresPassphrase: Boolean
) {
    LEVEL_1_READ(
        level = 1,
        title = "Level 1: Read Access",
        titleUrdu = "لیول 1: صرف پڑھنا",
        description = "Read files, logs, memory, and system metrics without system modifications.",
        descriptionUrdu = "فائلز اور لاگز پڑھنے کی محفوظ اجازت",
        color = CyberGreen,
        requiresUserApproval = false,
        requiresPassphrase = false
    ),
    LEVEL_2_NORMAL(
        level = 2,
        title = "Level 2: Normal Action",
        titleUrdu = "لیول 2: عام کارروائی",
        description = "Web searches, opening applications, clipboard copy, safe terminal commands.",
        descriptionUrdu = "ایپس کھولنا، انٹرنیٹ سرچ اور عام کام",
        color = CyberCyan,
        requiresUserApproval = false,
        requiresPassphrase = false
    ),
    LEVEL_3_WRITE(
        level = 3,
        title = "Level 3: Write & Modify",
        titleUrdu = "لیول 3: فائل بنانا اور لکھنا",
        description = "Create files, generate source code, update existing project files, run local builds.",
        descriptionUrdu = "کوڈ لکھنا، فائلز بنانا اور پروجیکٹ بلڈ کرنا",
        color = CyberElectric,
        requiresUserApproval = false,
        requiresPassphrase = false
    ),
    LEVEL_4_SENSITIVE(
        level = 4,
        title = "Level 4: Sensitive Action",
        titleUrdu = "لیول 4: حساس کارروائی (تصدیق درکار)",
        description = "Permanent file deletion, dependency modifications, Git push to remote, process termination.",
        descriptionUrdu = "فائل ڈیلیٹ کرنا، بیرونی پیکج انسٹال کرنا یا پروسیس بند کرنا",
        color = CyberAmber,
        requiresUserApproval = true,
        requiresPassphrase = false
    ),
    LEVEL_5_CRITICAL(
        level = 5,
        title = "Level 5: Critical Action",
        titleUrdu = "لیول 5: انتہائی اہم (پاس فریز لازمی)",
        description = "System wipe, API key exposure, production deployment, root execution.",
        descriptionUrdu = "سسٹم ری سیٹ، حساس کیز کا استعمال یا لائیو ڈپلائے",
        color = CyberCrimson,
        requiresUserApproval = true,
        requiresPassphrase = true
    );

    companion object {
        fun fromLevel(lvl: Int): PermissionLevel {
            return entries.firstOrNull { it.level == lvl } ?: LEVEL_1_READ
        }
    }
}
