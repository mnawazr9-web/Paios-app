package com.example.paios.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.paios.model.AiOperationMode
import com.example.paios.model.SpecialistAgent
import com.example.paios.model.SystemMetrics
import com.example.paios.ui.viewmodel.PaiosNavTab
import com.example.ui.theme.*

@Composable
fun PaiosTopBar(
    metrics: SystemMetrics,
    activeAgent: SpecialistAgent,
    isGenerating: Boolean,
    onEmergencyStop: () -> Unit,
    onResumeSystem: () -> Unit,
    onModeClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseAlpha by infiniteTransition.animateFloat(
        initialValue = 0.4f,
        targetValue = 1.0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = LinearEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseAlpha"
    )

    Surface(
        color = CyberSurface,
        modifier = modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .border(width = 1.dp, color = CyberBorder)
    ) {
        Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Logo & OS Title
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                Brush.linearGradient(
                                    listOf(CyberCyan, CyberBlue)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "π",
                            color = CyberBackground,
                            fontWeight = FontWeight.Black,
                            fontSize = 20.sp
                        )
                    }
                    Spacer(Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "PAIOS",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.ExtraBold,
                                letterSpacing = 1.5.sp,
                                color = CyberCyan
                            )
                            Spacer(Modifier.width(6.dp))
                            Text(
                                text = "OS 2.4",
                                style = MaterialTheme.typography.labelSmall,
                                color = CyberTextTertiary
                            )
                        }
                        Text(
                            text = "Autonomous AI Engineer",
                            style = MaterialTheme.typography.bodySmall,
                            color = CyberTextSecondary,
                            fontSize = 10.sp
                        )
                    }
                }

                // Top Actions: Mode Badge + Emergency Stop
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Mode Tag
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = when (metrics.activeMode) {
                            AiOperationMode.ONLINE -> CyberCyan.copy(alpha = 0.15f)
                            AiOperationMode.OFFLINE_ALLAMA -> CyberGreen.copy(alpha = 0.15f)
                            AiOperationMode.HYBRID -> CyberPurple.copy(alpha = 0.15f)
                        },
                        border = BorderStroke(
                            1.dp,
                            when (metrics.activeMode) {
                                AiOperationMode.ONLINE -> CyberCyan
                                AiOperationMode.OFFLINE_ALLAMA -> CyberGreen
                                AiOperationMode.HYBRID -> CyberPurple
                            }
                        ),
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onModeClick() }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(6.dp)
                                    .clip(CircleShape)
                                    .background(
                                        when (metrics.activeMode) {
                                            AiOperationMode.ONLINE -> CyberCyan
                                            AiOperationMode.OFFLINE_ALLAMA -> CyberGreen
                                            AiOperationMode.HYBRID -> CyberPurple
                                        }
                                    )
                            )
                            Spacer(Modifier.width(4.dp))
                            Text(
                                text = when (metrics.activeMode) {
                                    AiOperationMode.ONLINE -> "ONLINE"
                                    AiOperationMode.OFFLINE_ALLAMA -> "ALLAMA 🦙"
                                    AiOperationMode.HYBRID -> "HYBRID"
                                },
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = when (metrics.activeMode) {
                                    AiOperationMode.ONLINE -> CyberCyan
                                    AiOperationMode.OFFLINE_ALLAMA -> CyberGreen
                                    AiOperationMode.HYBRID -> CyberPurple
                                },
                                fontSize = 9.sp
                            )
                        }
                    }

                    // Emergency Stop Button
                    if (metrics.emergencyStopActive) {
                        Button(
                            onClick = onResumeSystem,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CyberGreen,
                                contentColor = CyberBackground
                            ),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier
                                .height(32.dp)
                                .testTag("resume_system_button")
                        ) {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("RESUME", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    } else {
                        Button(
                            onClick = onEmergencyStop,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CyberCrimson,
                                contentColor = Color.White
                            ),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            modifier = Modifier
                                .height(32.dp)
                                .testTag("emergency_stop_button")
                        ) {
                            Icon(Icons.Default.Stop, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("STOP", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(Modifier.height(8.dp))

            // Sub Header: Live System Telemetry Strip
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(CyberSurfaceElevated)
                    .padding(horizontal = 10.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Active Agent status
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(
                                if (isGenerating) activeAgent.badgeColor.copy(alpha = pulseAlpha)
                                else CyberGreen
                            )
                    )
                    Spacer(Modifier.width(6.dp))
                    Text(
                        text = activeAgent.title,
                        style = MaterialTheme.typography.labelSmall,
                        color = CyberTextPrimary,
                        fontSize = 11.sp
                    )
                }

                // CPU & RAM metrics
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "CPU ${if (isGenerating) 64 else metrics.cpuPercent}%",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = if (isGenerating) CyberAmber else CyberTextSecondary,
                        fontSize = 10.sp
                    )
                    Text(
                        text = "RAM ${metrics.ramUsedMb}MB",
                        style = MaterialTheme.typography.labelSmall,
                        fontFamily = FontFamily.Monospace,
                        color = CyberTextSecondary,
                        fontSize = 10.sp
                    )
                }
            }
        }
    }
}

@Composable
fun PaiosNavBar(
    currentTab: PaiosNavTab,
    onTabSelected: (PaiosNavTab) -> Unit,
    modifier: Modifier = Modifier
) {
    NavigationBar(
        containerColor = CyberSurface,
        contentColor = CyberCyan,
        tonalElevation = 8.dp,
        modifier = modifier
            .navigationBarsPadding()
            .border(width = 1.dp, color = CyberBorder)
    ) {
        PaiosNavTab.entries.forEach { tab ->
            val selected = currentTab == tab
            NavigationBarItem(
                selected = selected,
                onClick = { onTabSelected(tab) },
                icon = {
                    Icon(
                        imageVector = when (tab) {
                            PaiosNavTab.CHAT_VOICE -> Icons.Default.SmartToy
                            PaiosNavTab.PROJECT_IDE -> Icons.Default.Code
                            PaiosNavTab.AGENT_MATRIX -> Icons.Default.Hub
                            PaiosNavTab.OS_TOOLS -> Icons.Default.Terminal
                            PaiosNavTab.MEMORY_BRAIN -> Icons.Default.Psychology
                        },
                        contentDescription = tab.title,
                        tint = if (selected) CyberCyan else CyberTextTertiary
                    )
                },
                label = {
                    Text(
                        text = tab.title,
                        style = MaterialTheme.typography.labelSmall,
                        color = if (selected) CyberCyan else CyberTextTertiary,
                        fontSize = 10.sp,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = CyberCyan,
                    unselectedIconColor = CyberTextTertiary,
                    selectedTextColor = CyberCyan,
                    unselectedTextColor = CyberTextTertiary,
                    indicatorColor = CyberCyan.copy(alpha = 0.15f)
                ),
                modifier = Modifier.testTag("nav_tab_${tab.name.lowercase()}")
            )
        }
    }
}
