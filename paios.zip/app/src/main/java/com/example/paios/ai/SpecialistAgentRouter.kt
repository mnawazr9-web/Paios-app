package com.example.paios.ai

import com.example.paios.model.SpecialistAgent
import java.util.Locale

object SpecialistAgentRouter {

    fun routePrompt(prompt: String): SpecialistAgent {
        val lower = prompt.lowercase(Locale.ROOT)

        return when {
            // Urdu & English Coding & Architecture triggers
            lower.contains("بناؤ") || lower.contains("ایپ") || lower.contains("کوڈ") || lower.contains("پروجیکٹ") ||
            lower.contains("create") || lower.contains("build") || lower.contains("code") || lower.contains("app") ||
            lower.contains("website") || lower.contains("generate") || lower.contains("kotlin") || lower.contains("python") ||
            lower.contains("react") || lower.contains("flutter") -> {
                SpecialistAgent.CODING
            }

            // Debugging triggers
            lower.contains("فکس") || lower.contains("ایرر") || lower.contains("خرابی") || lower.contains("بگ") ||
            lower.contains("fix") || lower.contains("error") || lower.contains("bug") || lower.contains("debug") ||
            lower.contains("crash") || lower.contains("solve") -> {
                SpecialistAgent.DEBUGGING
            }

            // Testing triggers
            lower.contains("ٹیسٹ") || lower.contains("test") || lower.contains("unit test") || lower.contains("assert") -> {
                SpecialistAgent.TESTING
            }

            // Browser triggers
            lower.contains("براؤزر") || lower.contains("کروم") || lower.contains("یوٹیوب") || lower.contains("سرچ") ||
            lower.contains("chrome") || lower.contains("youtube") || lower.contains("search") || lower.contains("browser") ||
            lower.contains("google") || lower.contains("url") || lower.contains("web") -> {
                SpecialistAgent.BROWSER
            }

            // File System triggers
            lower.contains("فائل") || lower.contains("فولڈر") || lower.contains("ڈیلیٹ") || lower.contains("سیو") ||
            lower.contains("file") || lower.contains("folder") || lower.contains("save") || lower.contains("delete") ||
            lower.contains("rename") || lower.contains("move") || lower.contains("directory") -> {
                SpecialistAgent.FILE
            }

            // Terminal triggers
            lower.contains("ٹرمینل") || lower.contains("کمانڈ") || lower.contains("گٹ") ||
            lower.contains("terminal") || lower.contains("bash") || lower.contains("cli") || lower.contains("git") ||
            lower.contains("npm") || lower.contains("pip") || lower.contains("run") -> {
                SpecialistAgent.TERMINAL
            }

            // OS Automation triggers
            lower.contains("کھولو") || lower.contains("بند کرو") || lower.contains("کلپ بورڈ") || lower.contains("کیلکولیٹر") ||
            lower.contains("launch") || lower.contains("open") || lower.contains("close") || lower.contains("vs code") ||
            lower.contains("process") || lower.contains("clipboard") || lower.contains("calculator") -> {
                SpecialistAgent.OS_AUTOMATION
            }

            // Documentation triggers
            lower.contains("ڈاکیو") || lower.contains("دستاویز") || lower.contains("readme") ||
            lower.contains("doc") || lower.contains("documentation") || lower.contains("explain") -> {
                SpecialistAgent.DOCUMENTATION
            }

            // UI / UX triggers
            lower.contains("ڈیزائن") || lower.contains("اسٹائل") || lower.contains("theme") ||
            lower.contains("ui") || lower.contains("ux") || lower.contains("layout") || lower.contains("screen") -> {
                SpecialistAgent.UI_UX
            }

            // Memory & Learning triggers
            lower.contains("میموری") || lower.contains("یاد") || lower.contains("ہسٹری") ||
            lower.contains("memory") || lower.contains("remember") || lower.contains("preference") || lower.contains("history") -> {
                SpecialistAgent.MEMORY
            }

            // Vision triggers
            lower.contains("اسکرین") || lower.contains("تصویر") || lower.contains("vision") ||
            lower.contains("screen") || lower.contains("image") || lower.contains("ocr") || lower.contains("screenshot") -> {
                SpecialistAgent.VISION
            }

            // Voice triggers
            lower.contains("آواز") || lower.contains("سنو") || lower.contains("voice") ||
            lower.contains("speech") || lower.contains("listen") || lower.contains("speak") -> {
                SpecialistAgent.VOICE
            }

            else -> SpecialistAgent.MASTER
        }
    }
}
