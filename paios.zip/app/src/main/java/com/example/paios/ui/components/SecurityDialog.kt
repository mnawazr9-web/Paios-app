package com.example.paios.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.paios.model.PermissionLevel
import com.example.paios.model.SecurityApprovalRequest
import com.example.ui.theme.*

@Composable
fun SecurityConfirmationDialog(
    request: SecurityApprovalRequest,
    modifier: Modifier = Modifier
) {
    var passphraseInput by remember { mutableStateOf("") }
    var passphraseError by remember { mutableStateOf(false) }

    Dialog(onDismissRequest = request.onReject) {
        Surface(
            color = CyberSurface,
            shape = RoundedCornerShape(16.dp),
            border = BorderStroke(2.dp, if (request.level == PermissionLevel.LEVEL_5_CRITICAL) CyberCrimson else CyberAmber),
            modifier = modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Icon(
                    imageVector = if (request.level == PermissionLevel.LEVEL_5_CRITICAL) Icons.Default.Lock else Icons.Default.Warning,
                    contentDescription = null,
                    tint = if (request.level == PermissionLevel.LEVEL_5_CRITICAL) CyberCrimson else CyberAmber,
                    modifier = Modifier.size(44.dp)
                )

                Spacer(Modifier.height(12.dp))

                Text(
                    text = request.level.title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = if (request.level == PermissionLevel.LEVEL_5_CRITICAL) CyberCrimson else CyberAmber
                )

                Text(
                    text = request.level.titleUrdu,
                    style = MaterialTheme.typography.bodySmall,
                    color = CyberTextSecondary
                )

                Spacer(Modifier.height(12.dp))

                Surface(
                    color = CyberSurfaceElevated,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Text(
                            text = request.action,
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.Bold,
                            color = CyberTextPrimary
                        )
                        Text(
                            text = request.actionUrdu,
                            style = MaterialTheme.typography.bodySmall,
                            color = CyberCyan
                        )
                        Spacer(Modifier.height(4.dp))
                        Text(
                            text = request.details,
                            style = MaterialTheme.typography.bodySmall,
                            color = CyberTextSecondary
                        )
                    }
                }

                if (request.level.requiresPassphrase) {
                    Spacer(Modifier.height(12.dp))
                    OutlinedTextField(
                        value = passphraseInput,
                        onValueChange = {
                            passphraseInput = it
                            passphraseError = false
                        },
                        label = { Text("Enter Passphrase (PAIOS-ROOT)") },
                        isError = passphraseError,
                        modifier = Modifier.fillMaxWidth()
                    )
                    if (passphraseError) {
                        Text("Invalid passphrase!", color = CyberCrimson, fontSize = 11.sp)
                    }
                }

                Spacer(Modifier.height(20.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = request.onReject,
                        modifier = Modifier.weight(1f).testTag("security_reject_button")
                    ) {
                        Text("REJECT (منسوخ)")
                    }

                    Button(
                        onClick = {
                            if (request.level.requiresPassphrase && passphraseInput != "PAIOS-ROOT") {
                                passphraseError = true
                            } else {
                                request.onConfirm()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (request.level == PermissionLevel.LEVEL_5_CRITICAL) CyberCrimson else CyberAmber,
                            contentColor = CyberBackground
                        ),
                        modifier = Modifier.weight(1f).testTag("security_approve_button")
                    ) {
                        Text("APPROVE (اجازت)", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}
