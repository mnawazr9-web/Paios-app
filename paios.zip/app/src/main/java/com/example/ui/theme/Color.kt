package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// PAIOS Futuristic Cyber OS Palette
val CyberBackground = Color(0xFF0A0E17)
val CyberSurface = Color(0xFF111827)
val CyberSurfaceVariant = Color(0xFF1B2436)
val CyberSurfaceElevated = Color(0xFF222F46)

val CyberCyan = Color(0xFF00F0FF)
val CyberBlue = Color(0xFF0088FF)
val CyberElectric = Color(0xFF38BDF8)
val CyberEmerald = Color(0xFF10B981)
val CyberGreen = Color(0xFF00FF9D)
val CyberAmber = Color(0xFFF59E0B)
val CyberOrange = Color(0xFFFF7A00)
val CyberCrimson = Color(0xFFEF4444)
val CyberPurple = Color(0xFFA855F7)
val CyberPink = Color(0xFFEC4899)

val CyberTextPrimary = Color(0xFFF1F5F9)
val CyberTextSecondary = Color(0xFF94A3B8)
val CyberTextTertiary = Color(0xFF64748B)
val CyberBorder = Color(0xFF1E293B)
val CyberBorderGlow = Color(0xFF00F0FF).copy(alpha = 0.3f)

val TerminalBlack = Color(0xFF050811)
val CodeKeyword = Color(0xFFFF7B72)
val CodeString = Color(0xFFA5D6FF)
val CodeFunction = Color(0xFFD2A8FF)
val CodeComment = Color(0xFF8B949E)
val CodeNumber = Color(0xFF79C0FF)
