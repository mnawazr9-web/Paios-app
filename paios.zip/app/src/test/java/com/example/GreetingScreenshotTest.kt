package com.example

import androidx.compose.ui.test.junit4.createComposeRule
import androidx.compose.ui.test.onRoot
import com.example.paios.model.AiOperationMode
import com.example.paios.model.SpecialistAgent
import com.example.paios.model.SystemMetrics
import com.example.paios.ui.components.PaiosTopBar
import com.example.ui.theme.MyApplicationTheme
import com.github.takahirom.roborazzi.RobolectricDeviceQualifiers
import com.github.takahirom.roborazzi.captureRoboImage
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config
import org.robolectric.annotation.GraphicsMode

@RunWith(RobolectricTestRunner::class)
@GraphicsMode(GraphicsMode.Mode.NATIVE)
@Config(qualifiers = RobolectricDeviceQualifiers.Pixel8, sdk = [34])
class GreetingScreenshotTest {

  @get:Rule val composeTestRule = createComposeRule()

  @Test
  fun paios_topbar_screenshot() {
    composeTestRule.setContent {
      MyApplicationTheme {
        PaiosTopBar(
          metrics = SystemMetrics(activeMode = AiOperationMode.HYBRID),
          activeAgent = SpecialistAgent.MASTER,
          isGenerating = false,
          onEmergencyStop = {},
          onResumeSystem = {},
          onModeClick = {}
        )
      }
    }

    composeTestRule.onRoot().captureRoboImage(filePath = "src/test/screenshots/greeting.png")
  }
}
