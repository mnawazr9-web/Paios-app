package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.paios.ai.LocalHeuristicEngine
import com.example.paios.ai.SpecialistAgentRouter
import com.example.paios.model.SpecialistAgent
import com.example.paios.model.WorkflowStep
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read app name string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("PAIOS", appName)
  }

  @Test
  fun `test specialist agent routing for coding intent in urdu and english`() {
    val urduPrompt = "میرے لیے ایک چیٹ ایپ بناؤ"
    val agentUrdu = SpecialistAgentRouter.routePrompt(urduPrompt)
    assertEquals(SpecialistAgent.CODING, agentUrdu)

    val englishPrompt = "create a new android project with room"
    val agentEng = SpecialistAgentRouter.routePrompt(englishPrompt)
    assertEquals(SpecialistAgent.CODING, agentEng)
  }

  @Test
  fun `test specialist agent routing for browser and debugging`() {
    val browserPrompt = "YouTube کھولو اور ویڈیوز تلاش کرو"
    val agentBrowser = SpecialistAgentRouter.routePrompt(browserPrompt)
    assertEquals(SpecialistAgent.BROWSER, agentBrowser)

    val debugPrompt = "تمام errors اور بگز fix کرو"
    val agentDebug = SpecialistAgentRouter.routePrompt(debugPrompt)
    assertEquals(SpecialistAgent.DEBUGGING, agentDebug)
  }

  @Test
  fun `test local heuristic autonomous project generation`() {
    val result = LocalHeuristicEngine.processLocalCommand("create chat app", null)
    assertNotNull(result.project)
    assertTrue(result.files.isNotEmpty())
    assertEquals(WorkflowStep.COMPLETED, result.detectedStep)
  }
}
